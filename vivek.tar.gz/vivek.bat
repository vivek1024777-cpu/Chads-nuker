@echo off
title Chads Launcher
cd /d "%~dp0"

echo ===============================
echo   Starting Script
echo ===============================
echo.

echo Checking for requirements...
pip install -r requirements.txt

echo.
echo Running Chads.py...
echo.

:: Run script
python Chads.py

echo.
echo Script finished.
pause
